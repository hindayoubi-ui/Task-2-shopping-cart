/*!
 * Bootstrap v5.3.8 (https://getbootstrap.com/)
 * Copyright 2011-2025 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
!(function (t, e) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module.exports = e())
    : "function" == typeof define && define.amd
      ? define(e)
      : ((t =
          "undefined" != typeof globalThis ? globalThis : t || self).bootstrap =
          e());
})(this, function () {
  "use strict";
  const t = new Map(),
    e = {
      set(e, i, n) {
        t.has(e) || t.set(e, new Map());
        const s = t.get(e);
        s.has(i) || 0 === s.size
          ? s.set(i, n)
          : console.error(
              `Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(s.keys())[0]}.`,
            );
      },
      get: (e, i) => (t.has(e) && t.get(e).get(i)) || null,
      remove(e, i) {
        if (!t.has(e)) return;
        const n = t.get(e);
        (n.delete(i), 0 === n.size && t.delete(e));
      },
    },
    i = "transitionend",
    n = (t) => (
      t &&
        window.CSS &&
        window.CSS.escape &&
        (t = t.replace(/#([^\s"#']+)/g, (t, e) => `#${CSS.escape(e)}`)),
      t
    ),
    s = (t) =>
      null == t
        ? `${t}`
        : Object.prototype.toString
            .call(t)
            .match(/\s([a-z]+)/i)[1]
            .toLowerCase(),
    o = (t) => {
      t.dispatchEvent(new Event(i));
    },
    r = (t) =>
      !(!t || "object" != typeof t) &&
      (void 0 !== t.jquery && (t = t[0]), void 0 !== t.nodeType),
    a = (t) =>
      r(t)
        ? t.jquery
          ? t[0]
          : t
        : "string" == typeof t && t.length > 0
          ? document.querySelector(n(t))
          : null,
    l = (t) => {
      if (!r(t) || 0 === t.getClientRects().length) return !1;
      const e =
          "visible" === getComputedStyle(t).getPropertyValue("visibility"),
        i = t.closest("details:not([open])");
      if (!i) return e;
      if (i !== t) {
        const e = t.closest("summary");
        if (e && e.parentNode !== i) return !1;
        if (null === e) return !1;
      }
      return e;
    },
    c = (t) =>
      !t ||
      t.nodeType !== Node.ELEMENT_NODE ||
      !!t.classList.contains("disabled") ||
      (void 0 !== t.disabled
        ? t.disabled
        : t.hasAttribute("disabled") && "false" !== t.getAttribute("disabled")),
    h = (t) => {
      if (!document.documentElement.attachShadow) return null;
      if ("function" == typeof t.getRootNode) {
        const e = t.getRootNode();
        return e instanceof ShadowRoot ? e : null;
      }
      return t instanceof ShadowRoot
        ? t
        : t.parentNode
          ? h(t.parentNode)
          : null;
    },
    d = () => {},
    u = (t) => {
      t.offsetHeight;
    },
    f = () =>
      window.jQuery && !document.body.hasAttribute("data-bs-no-jquery")
        ? window.jQuery
        : null,
    p = [],
    m = () => "rtl" === document.documentElement.dir,
    g = (t) => {
      var e;
      ((e = () => {
        const e = f();
        if (e) {
          const i = t.NAME,
            n = e.fn[i];
          ((e.fn[i] = t.jQueryInterface),
            (e.fn[i].Constructor = t),
            (e.fn[i].noConflict = () => ((e.fn[i] = n), t.jQueryInterface)));
        }
      }),
        "loading" === document.readyState
          ? (p.length ||
              document.addEventListener("DOMContentLoaded", () => {
                for (const t of p) t();
              }),
            p.push(e))
          : e());
    },
    _ = (t, e = [], i = t) => ("function" == typeof t ? t.call(...e) : i),
    b = (t, e, n = !0) => {
      if (!n) return void _(t);
      const s =
        ((t) => {
          if (!t) return 0;
          let { transitionDuration: e, transitionDelay: i } =
            window.getComputedStyle(t);
          const n = Number.parseFloat(e),
            s = Number.parseFloat(i);
          return n || s
            ? ((e = e.split(",")[0]),
              (i = i.split(",")[0]),
              1e3 * (Number.parseFloat(e) + Number.parseFloat(i)))
            : 0;
        })(e) + 5;
      let r = !1;
      const a = ({ target: n }) => {
        n === e && ((r = !0), e.removeEventListener(i, a), _(t));
      };
      (e.addEventListener(i, a),
        setTimeout(() => {
          r || o(e);
        }, s));
    },
    v = (t, e, i, n) => {
      const s = t.length;
      let o = t.indexOf(e);
      return -1 === o
        ? !i && n
          ? t[s - 1]
          : t[0]
        : ((o += i ? 1 : -1),
          n && (o = (o + s) % s),
          t[Math.max(0, Math.min(o, s - 1))]);
    },
    y = /[^.]*(?=\..*)\.|.*/,
    w = /\..*/,
    A = /::\d+$/,
    E = {};
  let T = 1;
  const C = { mouseenter: "mouseover", mouseleave: "mouseout" },
    O = new Set([
      "click",
      "dblclick",
      "mouseup",
      "mousedown",
      "contextmenu",
      "mousewheel",
      "DOMMouseScroll",
      "mouseover",
      "mouseout",
      "mousemove",
      "selectstart",
      "selectend",
      "keydown",
      "keypress",
      "keyup",
      "orientationchange",
      "touchstart",
      "touchmove",
      "touchend",
      "touchcancel",
      "pointerdown",
      "pointermove",
      "pointerup",
      "pointerleave",
      "pointercancel",
      "gesturestart",
      "gesturechange",
      "gestureend",
      "focus",
      "blur",
      "change",
      "reset",
      "select",
      "submit",
      "focusin",
      "focusout",
      "load",
      "unload",
      "beforeunload",
      "resize",
      "move",
      "DOMContentLoaded",
      "readystatechange",
      "error",
      "abort",
      "scroll",
    ]);
  function x(t, e) {
    return (e && `${e}::${T++}`) || t.uidEvent || T++;
  }
  function k(t) {
    const e = x(t);
    return ((t.uidEvent = e), (E[e] = E[e] || {}), E[e]);
  }
  function L(t, e, i = null) {
    return Object.values(t).find(
      (t) => t.callable === e && t.delegationSelector === i,
    );
  }
  function S(t, e, i) {
    const n = "string" == typeof e,
      s = n ? i : e || i;
    let o = N(t);
    return (O.has(o) || (o = t), [n, s, o]);
  }
  function D(t, e, i, n, s) {
    if ("string" != typeof e || !t) return;
    let [o, r, a] = S(e, i, n);
    if (e in C) {
      const t = (t) =>
        function (e) {
          if (
            !e.relatedTarget ||
            (e.relatedTarget !== e.delegateTarget &&
              !e.delegateTarget.contains(e.relatedTarget))
          )
            return t.call(this, e);
        };
      r = t(r);
    }
    const l = k(t),
      c = l[a] || (l[a] = {}),
      h = L(c, r, o ? i : null);
    if (h) return void (h.oneOff = h.oneOff && s);
    const d = x(r, e.replace(y, "")),
      u = o
        ? (function (t, e, i) {
            return function n(s) {
              const o = t.querySelectorAll(e);
              for (let { target: r } = s; r && r !== this; r = r.parentNode)
                for (const a of o)
                  if (a === r)
                    return (
                      j(s, { delegateTarget: r }),
                      n.oneOff && P.off(t, s.type, e, i),
                      i.apply(r, [s])
                    );
            };
          })(t, i, r)
        : (function (t, e) {
            return function i(n) {
              return (
                j(n, { delegateTarget: t }),
                i.oneOff && P.off(t, n.type, e),
                e.apply(t, [n])
              );
            };
          })(t, r);
    ((u.delegationSelector = o ? i : null),
      (u.callable = r),
      (u.oneOff = s),
      (u.uidEvent = d),
      (c[d] = u),
      t.addEventListener(a, u, o));
  }
  function $(t, e, i, n, s) {
    const o = L(e[i], n, s);
    o && (t.removeEventListener(i, o, Boolean(s)), delete e[i][o.uidEvent]);
  }
  function I(t, e, i, n) {
    const s = e[i] || {};
    for (const [o, r] of Object.entries(s))
      o.includes(n) && $(t, e, i, r.callable, r.delegationSelector);
  }
  function N(t) {
    return ((t = t.replace(w, "")), C[t] || t);
  }
  const P = {
    on(t, e, i, n) {
      D(t, e, i, n, !1);
    },
    one(t, e, i, n) {
      D(t, e, i, n, !0);
    },
    off(t, e, i, n) {
      if ("string" != typeof e || !t) return;
      const [s, o, r] = S(e, i, n),
        a = r !== e,
        l = k(t),
        c = l[r] || {},
        h = e.startsWith(".");
      if (void 0 === o) {
        if (h) for (const i of Object.keys(l)) I(t, l, i, e.slice(1));
        for (const [i, n] of Object.entries(c)) {
          const s = i.replace(A, "");
          (a && !e.includes(s)) || $(t, l, r, n.callable, n.delegationSelector);
        }
      } else {
        if (!Object.keys(c).length) return;
        $(t, l, r, o, s ? i : null);
      }
    },
    trigger(t, e, i) {
      if ("string" != typeof e || !t) return null;
      const n = f();
      let s = null,
        o = !0,
        r = !0,
        a = !1;
      e !== N(e) &&
        n &&
        ((s = n.Event(e, i)),
        n(t).trigger(s),
        (o = !s.isPropagationStopped()),
        (r = !s.isImmediatePropagationStopped()),
        (a = s.isDefaultPrevented()));
      const l = j(new Event(e, { bubbles: o, cancelable: !0 }), i);
      return (
        a && l.preventDefault(),
        r && t.dispatchEvent(l),
        l.defaultPrevented && s && s.preventDefault(),
        l
      );
    },
  };
  function j(t, e = {}) {
    for (const [i, n] of Object.entries(e))
      try {
        t[i] = n;
      } catch (e) {
        Object.defineProperty(t, i, { configurable: !0, get: () => n });
      }
    return t;
  }
  function M(t) {
    if ("true" === t) return !0;
    if ("false" === t) return !1;
    if (t === Number(t).toString()) return Number(t);
    if ("" === t || "null" === t) return null;
    if ("string" != typeof t) return t;
    try {
      return JSON.parse(decodeURIComponent(t));
    } catch (e) {
      return t;
    }
  }
  function F(t) {
    return t.replace(/[A-Z]/g, (t) => `-${t.toLowerCase()}`);
  }
  const H = {
    setDataAttribute(t, e, i) {
      t.setAttribute(`data-bs-${F(e)}`, i);
    },
    removeDataAttribute(t, e) {
      t.removeAttribute(`data-bs-${F(e)}`);
    },
    getDataAttributes(t) {
      if (!t) return {};
      const e = {},
        i = Object.keys(t.dataset).filter(
          (t) => t.startsWith("bs") && !t.startsWith("bsConfig"),
        );
      for (const n of i) {
        let i = n.replace(/^bs/, "");
        ((i = i.charAt(0).toLowerCase() + i.slice(1)),
          (e[i] = M(t.dataset[n])));
      }
      return e;
    },
    getDataAttribute: (t, e) => M(t.getAttribute(`data-bs-${F(e)}`)),
  };
  class W {
    static get Default() {
      return {};
    }
    static get DefaultType() {
      return {};
    }
    static get NAME() {
      throw new Error(
        'You have to implement the static method "NAME", for each component!',
      );
    }
    _getConfig(t) {
      return (
        (t = this._mergeConfigObj(t)),
        (t = this._configAfterMerge(t)),
        this._typeCheckConfig(t),
        t
      );
    }
    _configAfterMerge(t) {
      return t;
    }
    _mergeConfigObj(t, e) {
      const i = r(e) ? H.getDataAttribute(e, "config") : {};
      return {
        ...this.constructor.Default,
        ...("object" == typeof i ? i : {}),
        ...(r(e) ? H.getDataAttributes(e) : {}),
        ...("object" == typeof t ? t : {}),
      };
    }
    _typeCheckConfig(t, e = this.constructor.DefaultType) {
      for (const [i, n] of Object.entries(e)) {
        const e = t[i],
          o = r(e) ? "element" : s(e);
        if (!new RegExp(n).test(o))
          throw new TypeError(
            `${this.constructor.NAME.toUpperCase()}: Option "${i}" provided type "${o}" but expected type "${n}".`,
          );
      }
    }
  }
  class B extends W {
    constructor(t, i) {
      (super(),
        (t = a(t)) &&
          ((this._element = t),
          (this._config = this._getConfig(i)),
          e.set(this._element, this.constructor.DATA_KEY, this)));
    }
    dispose() {
      (e.remove(this._element, this.constructor.DATA_KEY),
        P.off(this._element, this.constructor.EVENT_KEY));
      for (const t of Object.getOwnPropertyNames(this)) this[t] = null;
    }
    _queueCallback(t, e, i = !0) {
      b(t, e, i);
    }
    _getConfig(t) {
      return (
        (t = this._mergeConfigObj(t, this._element)),
        (t = this._configAfterMerge(t)),
        this._typeCheckConfig(t),
        t
      );
    }
    static getInstance(t) {
      return e.get(a(t), this.DATA_KEY);
    }
    static getOrCreateInstance(t, e = {}) {
      return (
        this.getInstance(t) || new this(t, "object" == typeof e ? e : null)
      );
    }
    static get VERSION() {
      return "5.3.8";
    }
    static get DATA_KEY() {
      return `bs.${this.NAME}`;
    }
    static get EVENT_KEY() {
      return `.${this.DATA_KEY}`;
    }
    static eventName(t) {
      return `${t}${this.EVENT_KEY}`;
    }
  }
  const z = (t) => {
      let e = t.getAttribute("data-bs-target");
      if (!e || "#" === e) {
        let i = t.getAttribute("href");
        if (!i || (!i.includes("#") && !i.startsWith("."))) return null;
        (i.includes("#") && !i.startsWith("#") && (i = `#${i.split("#")[1]}`),
          (e = i && "#" !== i ? i.trim() : null));
      }
      return e
        ? e
            .split(",")
            .map((t) => n(t))
            .join(",")
        : null;
    },
    R = {
      find: (t, e = document.documentElement) =>
        [].concat(...Element.prototype.querySelectorAll.call(e, t)),
      findOne: (t, e = document.documentElement) =>
        Element.prototype.querySelector.call(e, t),
      children: (t, e) => [].concat(...t.children).filter((t) => t.matches(e)),
      parents(t, e) {
        const i = [];
        let n = t.parentNode.closest(e);
        for (; n; ) (i.push(n), (n = n.parentNode.closest(e)));
        return i;
      },
      prev(t, e) {
        let i = t.previousElementSibling;
        for (; i; ) {
          if (i.matches(e)) return [i];
          i = i.previousElementSibling;
        }
        return [];
      },
      next(t, e) {
        let i = t.nextElementSibling;
        for (; i; ) {
          if (i.matches(e)) return [i];
          i = i.nextElementSibling;
        }
        return [];
      },
      focusableChildren(t) {
        const e = [
          "a",
          "button",
          "input",
          "textarea",
          "select",
          "details",
          "[tabindex]",
          '[contenteditable="true"]',
        ]
          .map((t) => `${t}:not([tabindex^="-"])`)
          .join(",");
        return this.find(e, t).filter((t) => !c(t) && l(t));
      },
      getSelectorFromElement(t) {
        const e = z(t);
        return e && R.findOne(e) ? e : null;
      },
      getElementFromSelector(t) {
        const e = z(t);
        return e ? R.findOne(e) : null;
      },
      getMultipleElementsFromSelector(t) {
        const e = z(t);
        return e ? R.find(e) : [];
      },
    },
    q = (t, e = "hide") => {
      const i = `click.dismiss${t.EVENT_KEY}`,
        n = t.NAME;
      P.on(document, i, `[data-bs-dismiss="${n}"]`, function (i) {
        if (
          (["A", "AREA"].includes(this.tagName) && i.preventDefault(), c(this))
        )
          return;
        const s = R.getElementFromSelector(this) || this.closest(`.${n}`);
        t.getOrCreateInstance(s)[e]();
      });
    },
    V = ".bs.alert",
    K = `close${V}`,
    Q = `closed${V}`;
  class X extends B {
    static get NAME() {
      return "alert";
    }
    close() {
      if (P.trigger(this._element, K).defaultPrevented) return;
      this._element.classList.remove("show");
      const t = this._element.classList.contains("fade");
      this._queueCallback(() => this._destroyElement(), this._element, t);
    }
    _destroyElement() {
      (this._element.remove(), P.trigger(this._element, Q), this.dispose());
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = X.getOrCreateInstance(this);
        if ("string" == typeof t) {
          if (void 0 === e[t] || t.startsWith("_") || "constructor" === t)
            throw new TypeError(`No method named "${t}"`);
          e[t](this);
        }
      });
    }
  }
  (q(X, "close"), g(X));
  const Y = '[data-bs-toggle="button"]';
  class U extends B {
    static get NAME() {
      return "button";
    }
    toggle() {
      this._element.setAttribute(
        "aria-pressed",
        this._element.classList.toggle("active"),
      );
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = U.getOrCreateInstance(this);
        "toggle" === t && e[t]();
      });
    }
  }
  (P.on(document, "click.bs.button.data-api", Y, (t) => {
    t.preventDefault();
    const e = t.target.closest(Y);
    U.getOrCreateInstance(e).toggle();
  }),
    g(U));
  const G = ".bs.swipe",
    J = `touchstart${G}`,
    Z = `touchmove${G}`,
    tt = `touchend${G}`,
    et = `pointerdown${G}`,
    it = `pointerup${G}`,
    nt = { endCallback: null, leftCallback: null, rightCallback: null },
    st = {
      endCallback: "(function|null)",
      leftCallback: "(function|null)",
      rightCallback: "(function|null)",
    };
  class ot extends W {
    constructor(t, e) {
      (super(),
        (this._element = t),
        t &&
          ot.isSupported() &&
          ((this._config = this._getConfig(e)),
          (this._deltaX = 0),
          (this._supportPointerEvents = Boolean(window.PointerEvent)),
          this._initEvents()));
    }
    static get Default() {
      return nt;
    }
    static get DefaultType() {
      return st;
    }
    static get NAME() {
      return "swipe";
    }
    dispose() {
      P.off(this._element, G);
    }
    _start(t) {
      this._supportPointerEvents
        ? this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX)
        : (this._deltaX = t.touches[0].clientX);
    }
    _end(t) {
      (this._eventIsPointerPenTouch(t) &&
        (this._deltaX = t.clientX - this._deltaX),
        this._handleSwipe(),
        _(this._config.endCallback));
    }
    _move(t) {
      this._deltaX =
        t.touches && t.touches.length > 1
          ? 0
          : t.touches[0].clientX - this._deltaX;
    }
    _handleSwipe() {
      const t = Math.abs(this._deltaX);
      if (t <= 40) return;
      const e = t / this._deltaX;
      ((this._deltaX = 0),
        e && _(e > 0 ? this._config.rightCallback : this._config.leftCallback));
    }
    _initEvents() {
      this._supportPointerEvents
        ? (P.on(this._element, et, (t) => this._start(t)),
          P.on(this._element, it, (t) => this._end(t)),
          this._element.classList.add("pointer-event"))
        : (P.on(this._element, J, (t) => this._start(t)),
          P.on(this._element, Z, (t) => this._move(t)),
          P.on(this._element, tt, (t) => this._end(t)));
    }
    _eventIsPointerPenTouch(t) {
      return (
        this._supportPointerEvents &&
        ("pen" === t.pointerType || "touch" === t.pointerType)
      );
    }
    static isSupported() {
      return (
        "ontouchstart" in document.documentElement ||
        navigator.maxTouchPoints > 0
      );
    }
  }
  const rt = ".bs.carousel",
    at = ".data-api",
    lt = "ArrowLeft",
    ct = "ArrowRight",
    ht = "next",
    dt = "prev",
    ut = "left",
    ft = "right",
    pt = `slide${rt}`,
    mt = `slid${rt}`,
    gt = `keydown${rt}`,
    _t = `mouseenter${rt}`,
    bt = `mouseleave${rt}`,
    vt = `dragstart${rt}`,
    yt = `load${rt}${at}`,
    wt = `click${rt}${at}`,
    At = "carousel",
    Et = "active",
    Tt = ".active",
    Ct = ".carousel-item",
    Ot = Tt + Ct,
    xt = { [lt]: ft, [ct]: ut },
    kt = {
      interval: 5e3,
      keyboard: !0,
      pause: "hover",
      ride: !1,
      touch: !0,
      wrap: !0,
    },
    Lt = {
      interval: "(number|boolean)",
      keyboard: "boolean",
      pause: "(string|boolean)",
      ride: "(boolean|string)",
      touch: "boolean",
      wrap: "boolean",
    };
  class St extends B {
    constructor(t, e) {
      (super(t, e),
        (this._interval = null),
        (this._activeElement = null),
        (this._isSliding = !1),
        (this.touchTimeout = null),
        (this._swipeHelper = null),
        (this._indicatorsElement = R.findOne(
          ".carousel-indicators",
          this._element,
        )),
        this._addEventListeners(),
        this._config.ride === At && this.cycle());
    }
    static get Default() {
      return kt;
    }
    static get DefaultType() {
      return Lt;
    }
    static get NAME() {
      return "carousel";
    }
    next() {
      this._slide(ht);
    }
    nextWhenVisible() {
      !document.hidden && l(this._element) && this.next();
    }
    prev() {
      this._slide(dt);
    }
    pause() {
      (this._isSliding && o(this._element), this._clearInterval());
    }
    cycle() {
      (this._clearInterval(),
        this._updateInterval(),
        (this._interval = setInterval(
          () => this.nextWhenVisible(),
          this._config.interval,
        )));
    }
    _maybeEnableCycle() {
      this._config.ride &&
        (this._isSliding
          ? P.one(this._element, mt, () => this.cycle())
          : this.cycle());
    }
    to(t) {
      const e = this._getItems();
      if (t > e.length - 1 || t < 0) return;
      if (this._isSliding)
        return void P.one(this._element, mt, () => this.to(t));
      const i = this._getItemIndex(this._getActive());
      if (i === t) return;
      const n = t > i ? ht : dt;
      this._slide(n, e[t]);
    }
    dispose() {
      (this._swipeHelper && this._swipeHelper.dispose(), super.dispose());
    }
    _configAfterMerge(t) {
      return ((t.defaultInterval = t.interval), t);
    }
    _addEventListeners() {
      (this._config.keyboard &&
        P.on(this._element, gt, (t) => this._keydown(t)),
        "hover" === this._config.pause &&
          (P.on(this._element, _t, () => this.pause()),
          P.on(this._element, bt, () => this._maybeEnableCycle())),
        this._config.touch &&
          ot.isSupported() &&
          this._addTouchEventListeners());
    }
    _addTouchEventListeners() {
      for (const t of R.find(".carousel-item img", this._element))
        P.on(t, vt, (t) => t.preventDefault());
      const t = {
        leftCallback: () => this._slide(this._directionToOrder(ut)),
        rightCallback: () => this._slide(this._directionToOrder(ft)),
        endCallback: () => {
          "hover" === this._config.pause &&
            (this.pause(),
            this.touchTimeout && clearTimeout(this.touchTimeout),
            (this.touchTimeout = setTimeout(
              () => this._maybeEnableCycle(),
              500 + this._config.interval,
            )));
        },
      };
      this._swipeHelper = new ot(this._element, t);
    }
    _keydown(t) {
      if (/input|textarea/i.test(t.target.tagName)) return;
      const e = xt[t.key];
      e && (t.preventDefault(), this._slide(this._directionToOrder(e)));
    }
    _getItemIndex(t) {
      return this._getItems().indexOf(t);
    }
    _setActiveIndicatorElement(t) {
      if (!this._indicatorsElement) return;
      const e = R.findOne(Tt, this._indicatorsElement);
      (e.classList.remove(Et), e.removeAttribute("aria-current"));
      const i = R.findOne(`[data-bs-slide-to="${t}"]`, this._indicatorsElement);
      i && (i.classList.add(Et), i.setAttribute("aria-current", "true"));
    }
    _updateInterval() {
      const t = this._activeElement || this._getActive();
      if (!t) return;
      const e = Number.parseInt(t.getAttribute("data-bs-interval"), 10);
      this._config.interval = e || this._config.defaultInterval;
    }
    _slide(t, e = null) {
      if (this._isSliding) return;
      const i = this._getActive(),
        n = t === ht,
        s = e || v(this._getItems(), i, n, this._config.wrap);
      if (s === i) return;
      const o = this._getItemIndex(s),
        r = (e) =>
          P.trigger(this._element, e, {
            relatedTarget: s,
            direction: this._orderToDirection(t),
            from: this._getItemIndex(i),
            to: o,
          });
      if (r(pt).defaultPrevented) return;
      if (!i || !s) return;
      const a = Boolean(this._interval);
      (this.pause(),
        (this._isSliding = !0),
        this._setActiveIndicatorElement(o),
        (this._activeElement = s));
      const l = n ? "carousel-item-start" : "carousel-item-end",
        c = n ? "carousel-item-next" : "carousel-item-prev";
      (s.classList.add(c),
        u(s),
        i.classList.add(l),
        s.classList.add(l),
        this._queueCallback(
          () => {
            (s.classList.remove(l, c),
              s.classList.add(Et),
              i.classList.remove(Et, c, l),
              (this._isSliding = !1),
              r(mt));
          },
          i,
          this._isAnimated(),
        ),
        a && this.cycle());
    }
    _isAnimated() {
      return this._element.classList.contains("slide");
    }
    _getActive() {
      return R.findOne(Ot, this._element);
    }
    _getItems() {
      return R.find(Ct, this._element);
    }
    _clearInterval() {
      this._interval &&
        (clearInterval(this._interval), (this._interval = null));
    }
    _directionToOrder(t) {
      return m() ? (t === ut ? dt : ht) : t === ut ? ht : dt;
    }
    _orderToDirection(t) {
      return m() ? (t === dt ? ut : ft) : t === dt ? ft : ut;
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = St.getOrCreateInstance(this, t);
        if ("number" != typeof t) {
          if ("string" == typeof t) {
            if (void 0 === e[t] || t.startsWith("_") || "constructor" === t)
              throw new TypeError(`No method named "${t}"`);
            e[t]();
          }
        } else e.to(t);
      });
    }
  }
  (P.on(document, wt, "[data-bs-slide], [data-bs-slide-to]", function (t) {
    const e = R.getElementFromSelector(this);
    if (!e || !e.classList.contains(At)) return;
    t.preventDefault();
    const i = St.getOrCreateInstance(e),
      n = this.getAttribute("data-bs-slide-to");
    return n
      ? (i.to(n), void i._maybeEnableCycle())
      : "next" === H.getDataAttribute(this, "slide")
        ? (i.next(), void i._maybeEnableCycle())
        : (i.prev(), void i._maybeEnableCycle());
  }),
    P.on(window, yt, () => {
      const t = R.find('[data-bs-ride="carousel"]');
      for (const e of t) St.getOrCreateInstance(e);
    }),
    g(St));
  const Dt = ".bs.collapse",
    $t = `show${Dt}`,
    It = `shown${Dt}`,
    Nt = `hide${Dt}`,
    Pt = `hidden${Dt}`,
    jt = `click${Dt}.data-api`,
    Mt = "show",
    Ft = "collapse",
    Ht = "collapsing",
    Wt = `:scope .${Ft} .${Ft}`,
    Bt = '[data-bs-toggle="collapse"]',
    zt = { parent: null, toggle: !0 },
    Rt = { parent: "(null|element)", toggle: "boolean" };
  class qt extends B {
    constructor(t, e) {
      (super(t, e), (this._isTransitioning = !1), (this._triggerArray = []));
      const i = R.find(Bt);
      for (const t of i) {
        const e = R.getSelectorFromElement(t),
          i = R.find(e).filter((t) => t === this._element);
        null !== e && i.length && this._triggerArray.push(t);
      }
      (this._initializeChildren(),
        this._config.parent ||
          this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()),
        this._config.toggle && this.toggle());
    }
    static get Default() {
      return zt;
    }
    static get DefaultType() {
      return Rt;
    }
    static get NAME() {
      return "collapse";
    }
    toggle() {
      this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (this._isTransitioning || this._isShown()) return;
      let t = [];
      if (
        (this._config.parent &&
          (t = this._getFirstLevelChildren(
            ".collapse.show, .collapse.collapsing",
          )
            .filter((t) => t !== this._element)
            .map((t) => qt.getOrCreateInstance(t, { toggle: !1 }))),
        t.length && t[0]._isTransitioning)
      )
        return;
      if (P.trigger(this._element, $t).defaultPrevented) return;
      for (const e of t) e.hide();
      const e = this._getDimension();
      (this._element.classList.remove(Ft),
        this._element.classList.add(Ht),
        (this._element.style[e] = 0),
        this._addAriaAndCollapsedClass(this._triggerArray, !0),
        (this._isTransitioning = !0));
      const i = `scroll${e[0].toUpperCase() + e.slice(1)}`;
      (this._queueCallback(
        () => {
          ((this._isTransitioning = !1),
            this._element.classList.remove(Ht),
            this._element.classList.add(Ft, Mt),
            (this._element.style[e] = ""),
            P.trigger(this._element, It));
        },
        this._element,
        !0,
      ),
        (this._element.style[e] = `${this._element[i]}px`));
    }
    hide() {
      if (this._isTransitioning || !this._isShown()) return;
      if (P.trigger(this._element, Nt).defaultPrevented) return;
      const t = this._getDimension();
      ((this._element.style[t] =
        `${this._element.getBoundingClientRect()[t]}px`),
        u(this._element),
        this._element.classList.add(Ht),
        this._element.classList.remove(Ft, Mt));
      for (const t of this._triggerArray) {
        const e = R.getElementFromSelector(t);
        e && !this._isShown(e) && this._addAriaAndCollapsedClass([t], !1);
      }
      ((this._isTransitioning = !0),
        (this._element.style[t] = ""),
        this._queueCallback(
          () => {
            ((this._isTransitioning = !1),
              this._element.classList.remove(Ht),
              this._element.classList.add(Ft),
              P.trigger(this._element, Pt));
          },
          this._element,
          !0,
        ));
    }
    _isShown(t = this._element) {
      return t.classList.contains(Mt);
    }
    _configAfterMerge(t) {
      return ((t.toggle = Boolean(t.toggle)), (t.parent = a(t.parent)), t);
    }
    _getDimension() {
      return this._element.classList.contains("collapse-horizontal")
        ? "width"
        : "height";
    }
    _initializeChildren() {
      if (!this._config.parent) return;
      const t = this._getFirstLevelChildren(Bt);
      for (const e of t) {
        const t = R.getElementFromSelector(e);
        t && this._addAriaAndCollapsedClass([e], this._isShown(t));
      }
    }
    _getFirstLevelChildren(t) {
      const e = R.find(Wt, this._config.parent);
      return R.find(t, this._config.parent).filter((t) => !e.includes(t));
    }
    _addAriaAndCollapsedClass(t, e) {
      if (t.length)
        for (const i of t)
          (i.classList.toggle("collapsed", !e),
            i.setAttribute("aria-expanded", e));
    }
    static jQueryInterface(t) {
      const e = {};
      return (
        "string" == typeof t && /show|hide/.test(t) && (e.toggle = !1),
        this.each(function () {
          const i = qt.getOrCreateInstance(this, e);
          if ("string" == typeof t) {
            if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
            i[t]();
          }
        })
      );
    }
  }
  (P.on(document, jt, Bt, function (t) {
    ("A" === t.target.tagName ||
      (t.delegateTarget && "A" === t.delegateTarget.tagName)) &&
      t.preventDefault();
    for (const t of R.getMultipleElementsFromSelector(this))
      qt.getOrCreateInstance(t, { toggle: !1 }).toggle();
  }),
    g(qt));
  var Vt = "top",
    Kt = "bottom",
    Qt = "right",
    Xt = "left",
    Yt = "auto",
    Ut = [Vt, Kt, Qt, Xt],
    Gt = "start",
    Jt = "end",
    Zt = "clippingParents",
    te = "viewport",
    ee = "popper",
    ie = "reference",
    ne = Ut.reduce(function (t, e) {
      return t.concat([e + "-" + Gt, e + "-" + Jt]);
    }, []),
    se = [].concat(Ut, [Yt]).reduce(function (t, e) {
      return t.concat([e, e + "-" + Gt, e + "-" + Jt]);
    }, []),
    oe = "beforeRead",
    re = "read",
    ae = "afterRead",
    le = "beforeMain",
    ce = "main",
    he = "afterMain",
    de = "beforeWrite",
    ue = "write",
    fe = "afterWrite",
    pe = [oe, re, ae, le, ce, he, de, ue, fe];
  function me(t) {
    return t ? (t.nodeName || "").toLowerCase() : null;
  }
  function ge(t) {
    if (null == t) return window;
    if ("[object Window]" !== t.toString()) {
      var e = t.ownerDocument;
      return (e && e.defaultView) || window;
    }
    return t;
  }
  function _e(t) {
    return t instanceof ge(t).Element || t instanceof Element;
  }
  function be(t) {
    return t instanceof ge(t).HTMLElement || t instanceof HTMLElement;
  }
  function ve(t) {
    return (
      "undefined" != typeof ShadowRoot &&
      (t instanceof ge(t).ShadowRoot || t instanceof ShadowRoot)
    );
  }
  const ye = {
    name: "applyStyles",
    enabled: !0,
    phase: "write",
    fn: function (t) {
      var e = t.state;
      Object.keys(e.elements).forEach(function (t) {
        var i = e.styles[t] || {},
          n = e.attributes[t] || {},
          s = e.elements[t];
        be(s) &&
          me(s) &&
          (Object.assign(s.style, i),
          Object.keys(n).forEach(function (t) {
            var e = n[t];
            !1 === e
              ? s.removeAttribute(t)
              : s.setAttribute(t, !0 === e ? "" : e);
          }));
      });
    },
    effect: function (t) {
      var e = t.state,
        i = {
          popper: {
            position: e.options.strategy,
            left: "0",
            top: "0",
            margin: "0",
          },
          arrow: { position: "absolute" },
          reference: {},
        };
      return (
        Object.assign(e.elements.popper.style, i.popper),
        (e.styles = i),
        e.elements.arrow && Object.assign(e.elements.arrow.style, i.arrow),
        function () {
          Object.keys(e.elements).forEach(function (t) {
            var n = e.elements[t],
              s = e.attributes[t] || {},
              o = Object.keys(
                e.styles.hasOwnProperty(t) ? e.styles[t] : i[t],
              ).reduce(function (t, e) {
                return ((t[e] = ""), t);
              }, {});
            be(n) &&
              me(n) &&
              (Object.assign(n.style, o),
              Object.keys(s).forEach(function (t) {
                n.removeAttribute(t);
              }));
          });
        }
      );
    },
    requires: ["computeStyles"],
  };
  function we(t) {
    return t.split("-")[0];
  }
  var Ae = Math.max,
    Ee = Math.min,
    Te = Math.round;
  function Ce() {
    var t = navigator.userAgentData;
    return null != t && t.brands && Array.isArray(t.brands)
      ? t.brands
          .map(function (t) {
            return t.brand + "/" + t.version;
          })
          .join(" ")
      : navigator.userAgent;
  }
  function Oe() {
    return !/^((?!chrome|android).)*safari/i.test(Ce());
  }
  function xe(t, e, i) {
    (void 0 === e && (e = !1), void 0 === i && (i = !1));
    var n = t.getBoundingClientRect(),
      s = 1,
      o = 1;
    e &&
      be(t) &&
      ((s = (t.offsetWidth > 0 && Te(n.width) / t.offsetWidth) || 1),
      (o = (t.offsetHeight > 0 && Te(n.height) / t.offsetHeight) || 1));
    var r = (_e(t) ? ge(t) : window).visualViewport,
      a = !Oe() && i,
      l = (n.left + (a && r ? r.offsetLeft : 0)) / s,
      c = (n.top + (a && r ? r.offsetTop : 0)) / o,
      h = n.width / s,
      d = n.height / o;
    return {
      width: h,
      height: d,
      top: c,
      right: l + h,
      bottom: c + d,
      left: l,
      x: l,
      y: c,
    };
  }
  function ke(t) {
    var e = xe(t),
      i = t.offsetWidth,
      n = t.offsetHeight;
    return (
      Math.abs(e.width - i) <= 1 && (i = e.width),
      Math.abs(e.height - n) <= 1 && (n = e.height),
      { x: t.offsetLeft, y: t.offsetTop, width: i, height: n }
    );
  }
  function Le(t, e) {
    var i = e.getRootNode && e.getRootNode();
    if (t.contains(e)) return !0;
    if (i && ve(i)) {
      var n = e;
      do {
        if (n && t.isSameNode(n)) return !0;
        n = n.parentNode || n.host;
      } while (n);
    }
    return !1;
  }
  function Se(t) {
    return ge(t).getComputedStyle(t);
  }
  function De(t) {
    return ["table", "td", "th"].indexOf(me(t)) >= 0;
  }
  function $e(t) {
    return ((_e(t) ? t.ownerDocument : t.document) || window.document)
      .documentElement;
  }
  function Ie(t) {
    return "html" === me(t)
      ? t
      : t.assignedSlot || t.parentNode || (ve(t) ? t.host : null) || $e(t);
  }
  function Ne(t) {
    return be(t) && "fixed" !== Se(t).position ? t.offsetParent : null;
  }
  function Pe(t) {
    for (var e = ge(t), i = Ne(t); i && De(i) && "static" === Se(i).position; )
      i = Ne(i);
    return i &&
      ("html" === me(i) || ("body" === me(i) && "static" === Se(i).position))
      ? e
      : i ||
          (function (t) {
            var e = /firefox/i.test(Ce());
            if (/Trident/i.test(Ce()) && be(t) && "fixed" === Se(t).position)
              return null;
            var i = Ie(t);
            for (
              ve(i) && (i = i.host);
              be(i) && ["html", "body"].indexOf(me(i)) < 0;
            ) {
              var n = Se(i);
              if (
                "none" !== n.transform ||
                "none" !== n.perspective ||
                "paint" === n.contain ||
                -1 !== ["transform", "perspective"].indexOf(n.willChange) ||
                (e && "filter" === n.willChange) ||
                (e && n.filter && "none" !== n.filter)
              )
                return i;
              i = i.parentNode;
            }
            return null;
          })(t) ||
          e;
  }
  function je(t) {
    return ["top", "bottom"].indexOf(t) >= 0 ? "x" : "y";
  }
  function Me(t, e, i) {
    return Ae(t, Ee(e, i));
  }
  function Fe(t) {
    return Object.assign({}, { top: 0, right: 0, bottom: 0, left: 0 }, t);
  }
  function He(t, e) {
    return e.reduce(function (e, i) {
      return ((e[i] = t), e);
    }, {});
  }
  const We = {
    name: "arrow",
    enabled: !0,
    phase: "main",
    fn: function (t) {
      var e,
        i = t.state,
        n = t.name,
        s = t.options,
        o = i.elements.arrow,
        r = i.modifiersData.popperOffsets,
        a = we(i.placement),
        l = je(a),
        c = [Xt, Qt].indexOf(a) >= 0 ? "height" : "width";
      if (o && r) {
        var h = (function (t, e) {
            return Fe(
              "number" !=
                typeof (t =
                  "function" == typeof t
                    ? t(Object.assign({}, e.rects, { placement: e.placement }))
                    : t)
                ? t
                : He(t, Ut),
            );
          })(s.padding, i),
          d = ke(o),
          u = "y" === l ? Vt : Xt,
          f = "y" === l ? Kt : Qt,
          p =
            i.rects.reference[c] +
            i.rects.reference[l] -
            r[l] -
            i.rects.popper[c],
          m = r[l] - i.rects.reference[l],
          g = Pe(o),
          _ = g ? ("y" === l ? g.clientHeight || 0 : g.clientWidth || 0) : 0,
          b = p / 2 - m / 2,
          v = h[u],
          y = _ - d[c] - h[f],
          w = _ / 2 - d[c] / 2 + b,
          A = Me(v, w, y),
          E = l;
        i.modifiersData[n] = (((e = {})[E] = A), (e.centerOffset = A - w), e);
      }
    },
    effect: function (t) {
      var e = t.state,
        i = t.options.element,
        n = void 0 === i ? "[data-popper-arrow]" : i;
      null != n &&
        ("string" != typeof n || (n = e.elements.popper.querySelector(n))) &&
        Le(e.elements.popper, n) &&
        (e.elements.arrow = n);
    },
    requires: ["popperOffsets"],
    requiresIfExists: ["preventOverflow"],
  };
  function Be(t) {
    return t.split("-")[1];
  }
  var ze = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
  function Re(t) {
    var e,
      i = t.popper,
      n = t.popperRect,
      s = t.placement,
      o = t.variation,
      r = t.offsets,
      a = t.position,
      l = t.gpuAcceleration,
      c = t.adaptive,
      h = t.roundOffsets,
      d = t.isFixed,
      u = r.x,
      f = void 0 === u ? 0 : u,
      p = r.y,
      m = void 0 === p ? 0 : p,
      g = "function" == typeof h ? h({ x: f, y: m }) : { x: f, y: m };
    ((f = g.x), (m = g.y));
    var _ = r.hasOwnProperty("x"),
      b = r.hasOwnProperty("y"),
      v = Xt,
      y = Vt,
      w = window;
    if (c) {
      var A = Pe(i),
        E = "clientHeight",
        T = "clientWidth";
      (A === ge(i) &&
        "static" !== Se((A = $e(i))).position &&
        "absolute" === a &&
        ((E = "scrollHeight"), (T = "scrollWidth")),
        (s === Vt || ((s === Xt || s === Qt) && o === Jt)) &&
          ((y = Kt),
          (m -=
            (d && A === w && w.visualViewport
              ? w.visualViewport.height
              : A[E]) - n.height),
          (m *= l ? 1 : -1)),
        (s !== Xt && ((s !== Vt && s !== Kt) || o !== Jt)) ||
          ((v = Qt),
          (f -=
            (d && A === w && w.visualViewport ? w.visualViewport.width : A[T]) -
            n.width),
          (f *= l ? 1 : -1)));
    }
    var C,
      O = Object.assign({ position: a }, c && ze),
      x =
        !0 === h
          ? (function (t, e) {
              var i = t.x,
                n = t.y,
                s = e.devicePixelRatio || 1;
              return { x: Te(i * s) / s || 0, y: Te(n * s) / s || 0 };
            })({ x: f, y: m }, ge(i))
          : { x: f, y: m };
    return (
      (f = x.x),
      (m = x.y),
      l
        ? Object.assign(
            {},
            O,
            (((C = {})[y] = b ? "0" : ""),
            (C[v] = _ ? "0" : ""),
            (C.transform =
              (w.devicePixelRatio || 1) <= 1
                ? "translate(" + f + "px, " + m + "px)"
                : "translate3d(" + f + "px, " + m + "px, 0)"),
            C),
          )
        : Object.assign(
            {},
            O,
            (((e = {})[y] = b ? m + "px" : ""),
            (e[v] = _ ? f + "px" : ""),
            (e.transform = ""),
            e),
          )
    );
  }
  const qe = {
    name: "computeStyles",
    enabled: !0,
    phase: "beforeWrite",
    fn: function (t) {
      var e = t.state,
        i = t.options,
        n = i.gpuAcceleration,
        s = void 0 === n || n,
        o = i.adaptive,
        r = void 0 === o || o,
        a = i.roundOffsets,
        l = void 0 === a || a,
        c = {
          placement: we(e.placement),
          variation: Be(e.placement),
          popper: e.elements.popper,
          popperRect: e.rects.popper,
          gpuAcceleration: s,
          isFixed: "fixed" === e.options.strategy,
        };
      (null != e.modifiersData.popperOffsets &&
        (e.styles.popper = Object.assign(
          {},
          e.styles.popper,
          Re(
            Object.assign({}, c, {
              offsets: e.modifiersData.popperOffsets,
              position: e.options.strategy,
              adaptive: r,
              roundOffsets: l,
            }),
          ),
        )),
        null != e.modifiersData.arrow &&
          (e.styles.arrow = Object.assign(
            {},
            e.styles.arrow,
            Re(
              Object.assign({}, c, {
                offsets: e.modifiersData.arrow,
                position: "absolute",
                adaptive: !1,
                roundOffsets: l,
              }),
            ),
          )),
        (e.attributes.popper = Object.assign({}, e.attributes.popper, {
          "data-popper-placement": e.placement,
        })));
    },
    data: {},
  };
  var Ve = { passive: !0 };
  const Ke = {
    name: "eventListeners",
    enabled: !0,
    phase: "write",
    fn: function () {},
    effect: function (t) {
      var e = t.state,
        i = t.instance,
        n = t.options,
        s = n.scroll,
        o = void 0 === s || s,
        r = n.resize,
        a = void 0 === r || r,
        l = ge(e.elements.popper),
        c = [].concat(e.scrollParents.reference, e.scrollParents.popper);
      return (
        o &&
          c.forEach(function (t) {
            t.addEventListener("scroll", i.update, Ve);
          }),
        a && l.addEventListener("resize", i.update, Ve),
        function () {
          (o &&
            c.forEach(function (t) {
              t.removeEventListener("scroll", i.update, Ve);
            }),
            a && l.removeEventListener("resize", i.update, Ve));
        }
      );
    },
    data: {},
  };
  var Qe = { left: "right", right: "left", bottom: "top", top: "bottom" };
  function Xe(t) {
    return t.replace(/left|right|bottom|top/g, function (t) {
      return Qe[t];
    });
  }
  var Ye = { start: "end", end: "start" };
  function Ue(t) {
    return t.replace(/start|end/g, function (t) {
      return Ye[t];
    });
  }
  function Ge(t) {
    var e = ge(t);
    return { scrollLeft: e.pageXOffset, scrollTop: e.pageYOffset };
  }
  function Je(t) {
    return xe($e(t)).left + Ge(t).scrollLeft;
  }
  function Ze(t) {
    var e = Se(t),
      i = e.overflow,
      n = e.overflowX,
      s = e.overflowY;
    return /auto|scroll|overlay|hidden/.test(i + s + n);
  }
  function ti(t) {
    return ["html", "body", "#document"].indexOf(me(t)) >= 0
      ? t.ownerDocument.body
      : be(t) && Ze(t)
        ? t
        : ti(Ie(t));
  }
  function ei(t, e) {
    var i;
    void 0 === e && (e = []);
    var n = ti(t),
      s = n === (null == (i = t.ownerDocument) ? void 0 : i.body),
      o = ge(n),
      r = s ? [o].concat(o.visualViewport || [], Ze(n) ? n : []) : n,
      a = e.concat(r);
    return s ? a : a.concat(ei(Ie(r)));
  }
  function ii(t) {
    return Object.assign({}, t, {
      left: t.x,
      top: t.y,
      right: t.x + t.width,
      bottom: t.y + t.height,
    });
  }
  function ni(t, e, i) {
    return e === te
      ? ii(
          (function (t, e) {
            var i = ge(t),
              n = $e(t),
              s = i.visualViewport,
              o = n.clientWidth,
              r = n.clientHeight,
              a = 0,
              l = 0;
            if (s) {
              ((o = s.width), (r = s.height));
              var c = Oe();
              (c || (!c && "fixed" === e)) &&
                ((a = s.offsetLeft), (l = s.offsetTop));
            }
            return { width: o, height: r, x: a + Je(t), y: l };
          })(t, i),
        )
      : _e(e)
        ? (function (t, e) {
            var i = xe(t, !1, "fixed" === e);
            return (
              (i.top = i.top + t.clientTop),
              (i.left = i.left + t.clientLeft),
              (i.bottom = i.top + t.clientHeight),
              (i.right = i.left + t.clientWidth),
              (i.width = t.clientWidth),
              (i.height = t.clientHeight),
              (i.x = i.left),
              (i.y = i.top),
              i
            );
          })(e, i)
        : ii(
            (function (t) {
              var e,
                i = $e(t),
                n = Ge(t),
                s = null == (e = t.ownerDocument) ? void 0 : e.body,
                o = Ae(
                  i.scrollWidth,
                  i.clientWidth,
                  s ? s.scrollWidth : 0,
                  s ? s.clientWidth : 0,
                ),
                r = Ae(
                  i.scrollHeight,
                  i.clientHeight,
                  s ? s.scrollHeight : 0,
                  s ? s.clientHeight : 0,
                ),
                a = -n.scrollLeft + Je(t),
                l = -n.scrollTop;
              return (
                "rtl" === Se(s || i).direction &&
                  (a += Ae(i.clientWidth, s ? s.clientWidth : 0) - o),
                { width: o, height: r, x: a, y: l }
              );
            })($e(t)),
          );
  }
  function si(t) {
    var e,
      i = t.reference,
      n = t.element,
      s = t.placement,
      o = s ? we(s) : null,
      r = s ? Be(s) : null,
      a = i.x + i.width / 2 - n.width / 2,
      l = i.y + i.height / 2 - n.height / 2;
    switch (o) {
      case Vt:
        e = { x: a, y: i.y - n.height };
        break;
      case Kt:
        e = { x: a, y: i.y + i.height };
        break;
      case Qt:
        e = { x: i.x + i.width, y: l };
        break;
      case Xt:
        e = { x: i.x - n.width, y: l };
        break;
      default:
        e = { x: i.x, y: i.y };
    }
    var c = o ? je(o) : null;
    if (null != c) {
      var h = "y" === c ? "height" : "width";
      switch (r) {
        case Gt:
          e[c] = e[c] - (i[h] / 2 - n[h] / 2);
          break;
        case Jt:
          e[c] = e[c] + (i[h] / 2 - n[h] / 2);
      }
    }
    return e;
  }
  function oi(t, e) {
    void 0 === e && (e = {});
    var i = e,
      n = i.placement,
      s = void 0 === n ? t.placement : n,
      o = i.strategy,
      r = void 0 === o ? t.strategy : o,
      a = i.boundary,
      l = void 0 === a ? Zt : a,
      c = i.rootBoundary,
      h = void 0 === c ? te : c,
      d = i.elementContext,
      u = void 0 === d ? ee : d,
      f = i.altBoundary,
      p = void 0 !== f && f,
      m = i.padding,
      g = void 0 === m ? 0 : m,
      _ = Fe("number" != typeof g ? g : He(g, Ut)),
      b = u === ee ? ie : ee,
      v = t.rects.popper,
      y = t.elements[p ? b : u],
      w = (function (t, e, i, n) {
        var s =
            "clippingParents" === e
              ? (function (t) {
                  var e = ei(Ie(t)),
                    i =
                      ["absolute", "fixed"].indexOf(Se(t).position) >= 0 &&
                      be(t)
                        ? Pe(t)
                        : t;
                  return _e(i)
                    ? e.filter(function (t) {
                        return _e(t) && Le(t, i) && "body" !== me(t);
                      })
                    : [];
                })(t)
              : [].concat(e),
          o = [].concat(s, [i]),
          r = o[0],
          a = o.reduce(
            function (e, i) {
              var s = ni(t, i, n);
              return (
                (e.top = Ae(s.top, e.top)),
                (e.right = Ee(s.right, e.right)),
                (e.bottom = Ee(s.bottom, e.bottom)),
                (e.left = Ae(s.left, e.left)),
                e
              );
            },
            ni(t, r, n),
          );
        return (
          (a.width = a.right - a.left),
          (a.height = a.bottom - a.top),
          (a.x = a.left),
          (a.y = a.top),
          a
        );
      })(_e(y) ? y : y.contextElement || $e(t.elements.popper), l, h, r),
      A = xe(t.elements.reference),
      E = si({ reference: A, element: v, placement: s }),
      T = ii(Object.assign({}, v, E)),
      C = u === ee ? T : A,
      O = {
        top: w.top - C.top + _.top,
        bottom: C.bottom - w.bottom + _.bottom,
        left: w.left - C.left + _.left,
        right: C.right - w.right + _.right,
      },
      x = t.modifiersData.offset;
    if (u === ee && x) {
      var k = x[s];
      Object.keys(O).forEach(function (t) {
        var e = [Qt, Kt].indexOf(t) >= 0 ? 1 : -1,
          i = [Vt, Kt].indexOf(t) >= 0 ? "y" : "x";
        O[t] += k[i] * e;
      });
    }
    return O;
  }
  function ri(t, e) {
    void 0 === e && (e = {});
    var i = e,
      n = i.placement,
      s = i.boundary,
      o = i.rootBoundary,
      r = i.padding,
      a = i.flipVariations,
      l = i.allowedAutoPlacements,
      c = void 0 === l ? se : l,
      h = Be(n),
      d = h
        ? a
          ? ne
          : ne.filter(function (t) {
              return Be(t) === h;
            })
        : Ut,
      u = d.filter(function (t) {
        return c.indexOf(t) >= 0;
      });
    0 === u.length && (u = d);
    var f = u.reduce(function (e, i) {
      return (
        (e[i] = oi(t, {
          placement: i,
          boundary: s,
          rootBoundary: o,
          padding: r,
        })[we(i)]),
        e
      );
    }, {});
    return Object.keys(f).sort(function (t, e) {
      return f[t] - f[e];
    });
  }
  const ai = {
    name: "flip",
    enabled: !0,
    phase: "main",
    fn: function (t) {
      var e = t.state,
        i = t.options,
        n = t.name;
      if (!e.modifiersData[n]._skip) {
        for (
          var s = i.mainAxis,
            o = void 0 === s || s,
            r = i.altAxis,
            a = void 0 === r || r,
            l = i.fallbackPlacements,
            c = i.padding,
            h = i.boundary,
            d = i.rootBoundary,
            u = i.altBoundary,
            f = i.flipVariations,
            p = void 0 === f || f,
            m = i.allowedAutoPlacements,
            g = e.options.placement,
            _ = we(g),
            b =
              l ||
              (_ !== g && p
                ? (function (t) {
                    if (we(t) === Yt) return [];
                    var e = Xe(t);
                    return [Ue(t), e, Ue(e)];
                  })(g)
                : [Xe(g)]),
            v = [g].concat(b).reduce(function (t, i) {
              return t.concat(
                we(i) === Yt
                  ? ri(e, {
                      placement: i,
                      boundary: h,
                      rootBoundary: d,
                      padding: c,
                      flipVariations: p,
                      allowedAutoPlacements: m,
                    })
                  : i,
              );
            }, []),
            y = e.rects.reference,
            w = e.rects.popper,
            A = new Map(),
            E = !0,
            T = v[0],
            C = 0;
          C < v.length;
          C++
        ) {
          var O = v[C],
            x = we(O),
            k = Be(O) === Gt,
            L = [Vt, Kt].indexOf(x) >= 0,
            S = L ? "width" : "height",
            D = oi(e, {
              placement: O,
              boundary: h,
              rootBoundary: d,
              altBoundary: u,
              padding: c,
            }),
            $ = L ? (k ? Qt : Xt) : k ? Kt : Vt;
          y[S] > w[S] && ($ = Xe($));
          var I = Xe($),
            N = [];
          if (
            (o && N.push(D[x] <= 0),
            a && N.push(D[$] <= 0, D[I] <= 0),
            N.every(function (t) {
              return t;
            }))
          ) {
            ((T = O), (E = !1));
            break;
          }
          A.set(O, N);
        }
        if (E)
          for (
            var P = function (t) {
                var e = v.find(function (e) {
                  var i = A.get(e);
                  if (i)
                    return i.slice(0, t).every(function (t) {
                      return t;
                    });
                });
                if (e) return ((T = e), "break");
              },
              j = p ? 3 : 1;
            j > 0 && "break" !== P(j);
            j--
          );
        e.placement !== T &&
          ((e.modifiersData[n]._skip = !0), (e.placement = T), (e.reset = !0));
      }
    },
    requiresIfExists: ["offset"],
    data: { _skip: !1 },
  };
  function li(t, e, i) {
    return (
      void 0 === i && (i = { x: 0, y: 0 }),
      {
        top: t.top - e.height - i.y,
        right: t.right - e.width + i.x,
        bottom: t.bottom - e.height + i.y,
        left: t.left - e.width - i.x,
      }
    );
  }
  function ci(t) {
    return [Vt, Qt, Kt, Xt].some(function (e) {
      return t[e] >= 0;
    });
  }
  const hi = {
      name: "hide",
      enabled: !0,
      phase: "main",
      requiresIfExists: ["preventOverflow"],
      fn: function (t) {
        var e = t.state,
          i = t.name,
          n = e.rects.reference,
          s = e.rects.popper,
          o = e.modifiersData.preventOverflow,
          r = oi(e, { elementContext: "reference" }),
          a = oi(e, { altBoundary: !0 }),
          l = li(r, n),
          c = li(a, s, o),
          h = ci(l),
          d = ci(c);
        ((e.modifiersData[i] = {
          referenceClippingOffsets: l,
          popperEscapeOffsets: c,
          isReferenceHidden: h,
          hasPopperEscaped: d,
        }),
          (e.attributes.popper = Object.assign({}, e.attributes.popper, {
            "data-popper-reference-hidden": h,
            "data-popper-escaped": d,
          })));
      },
    },
    di = {
      name: "offset",
      enabled: !0,
      phase: "main",
      requires: ["popperOffsets"],
      fn: function (t) {
        var e = t.state,
          i = t.options,
          n = t.name,
          s = i.offset,
          o = void 0 === s ? [0, 0] : s,
          r = se.reduce(function (t, i) {
            return (
              (t[i] = (function (t, e, i) {
                var n = we(t),
                  s = [Xt, Vt].indexOf(n) >= 0 ? -1 : 1,
                  o =
                    "function" == typeof i
                      ? i(Object.assign({}, e, { placement: t }))
                      : i,
                  r = o[0],
                  a = o[1];
                return (
                  (r = r || 0),
                  (a = (a || 0) * s),
                  [Xt, Qt].indexOf(n) >= 0 ? { x: a, y: r } : { x: r, y: a }
                );
              })(i, e.rects, o)),
              t
            );
          }, {}),
          a = r[e.placement],
          l = a.x,
          c = a.y;
        (null != e.modifiersData.popperOffsets &&
          ((e.modifiersData.popperOffsets.x += l),
          (e.modifiersData.popperOffsets.y += c)),
          (e.modifiersData[n] = r));
      },
    },
    ui = {
      name: "popperOffsets",
      enabled: !0,
      phase: "read",
      fn: function (t) {
        var e = t.state,
          i = t.name;
        e.modifiersData[i] = si({
          reference: e.rects.reference,
          element: e.rects.popper,
          placement: e.placement,
        });
      },
      data: {},
    },
    fi = {
      name: "preventOverflow",
      enabled: !0,
      phase: "main",
      fn: function (t) {
        var e = t.state,
          i = t.options,
          n = t.name,
          s = i.mainAxis,
          o = void 0 === s || s,
          r = i.altAxis,
          a = void 0 !== r && r,
          l = i.boundary,
          c = i.rootBoundary,
          h = i.altBoundary,
          d = i.padding,
          u = i.tether,
          f = void 0 === u || u,
          p = i.tetherOffset,
          m = void 0 === p ? 0 : p,
          g = oi(e, {
            boundary: l,
            rootBoundary: c,
            padding: d,
            altBoundary: h,
          }),
          _ = we(e.placement),
          b = Be(e.placement),
          v = !b,
          y = je(_),
          w = "x" === y ? "y" : "x",
          A = e.modifiersData.popperOffsets,
          E = e.rects.reference,
          T = e.rects.popper,
          C =
            "function" == typeof m
              ? m(Object.assign({}, e.rects, { placement: e.placement }))
              : m,
          O =
            "number" == typeof C
              ? { mainAxis: C, altAxis: C }
              : Object.assign({ mainAxis: 0, altAxis: 0 }, C),
          x = e.modifiersData.offset
            ? e.modifiersData.offset[e.placement]
            : null,
          k = { x: 0, y: 0 };
        if (A) {
          if (o) {
            var L,
              S = "y" === y ? Vt : Xt,
              D = "y" === y ? Kt : Qt,
              $ = "y" === y ? "height" : "width",
              I = A[y],
              N = I + g[S],
              P = I - g[D],
              j = f ? -T[$] / 2 : 0,
              M = b === Gt ? E[$] : T[$],
              F = b === Gt ? -T[$] : -E[$],
              H = e.elements.arrow,
              W = f && H ? ke(H) : { width: 0, height: 0 },
              B = e.modifiersData["arrow#persistent"]
                ? e.modifiersData["arrow#persistent"].padding
                : { top: 0, right: 0, bottom: 0, left: 0 },
              z = B[S],
              R = B[D],
              q = Me(0, E[$], W[$]),
              V = v
                ? E[$] / 2 - j - q - z - O.mainAxis
                : M - q - z - O.mainAxis,
              K = v
                ? -E[$] / 2 + j + q + R + O.mainAxis
                : F + q + R + O.mainAxis,
              Q = e.elements.arrow && Pe(e.elements.arrow),
              X = Q ? ("y" === y ? Q.clientTop || 0 : Q.clientLeft || 0) : 0,
              Y = null != (L = null == x ? void 0 : x[y]) ? L : 0,
              U = I + K - Y,
              G = Me(f ? Ee(N, I + V - Y - X) : N, I, f ? Ae(P, U) : P);
            ((A[y] = G), (k[y] = G - I));
          }
          if (a) {
            var J,
              Z = "x" === y ? Vt : Xt,
              tt = "x" === y ? Kt : Qt,
              et = A[w],
              it = "y" === w ? "height" : "width",
              nt = et + g[Z],
              st = et - g[tt],
              ot = -1 !== [Vt, Xt].indexOf(_),
              rt = null != (J = null == x ? void 0 : x[w]) ? J : 0,
              at = ot ? nt : et - E[it] - T[it] - rt + O.altAxis,
              lt = ot ? et + E[it] + T[it] - rt - O.altAxis : st,
              ct =
                f && ot
                  ? (function (t, e, i) {
                      var n = Me(t, e, i);
                      return n > i ? i : n;
                    })(at, et, lt)
                  : Me(f ? at : nt, et, f ? lt : st);
            ((A[w] = ct), (k[w] = ct - et));
          }
          e.modifiersData[n] = k;
        }
      },
      requiresIfExists: ["offset"],
    };
  function pi(t, e, i) {
    void 0 === i && (i = !1);
    var n,
      s,
      o = be(e),
      r =
        be(e) &&
        (function (t) {
          var e = t.getBoundingClientRect(),
            i = Te(e.width) / t.offsetWidth || 1,
            n = Te(e.height) / t.offsetHeight || 1;
          return 1 !== i || 1 !== n;
        })(e),
      a = $e(e),
      l = xe(t, r, i),
      c = { scrollLeft: 0, scrollTop: 0 },
      h = { x: 0, y: 0 };
    return (
      (o || (!o && !i)) &&
        (("body" !== me(e) || Ze(a)) &&
          (c =
            (n = e) !== ge(n) && be(n)
              ? { scrollLeft: (s = n).scrollLeft, scrollTop: s.scrollTop }
              : Ge(n)),
        be(e)
          ? (((h = xe(e, !0)).x += e.clientLeft), (h.y += e.clientTop))
          : a && (h.x = Je(a))),
      {
        x: l.left + c.scrollLeft - h.x,
        y: l.top + c.scrollTop - h.y,
        width: l.width,
        height: l.height,
      }
    );
  }
  function mi(t) {
    var e = new Map(),
      i = new Set(),
      n = [];
    function s(t) {
      (i.add(t.name),
        []
          .concat(t.requires || [], t.requiresIfExists || [])
          .forEach(function (t) {
            if (!i.has(t)) {
              var n = e.get(t);
              n && s(n);
            }
          }),
        n.push(t));
    }
    return (
      t.forEach(function (t) {
        e.set(t.name, t);
      }),
      t.forEach(function (t) {
        i.has(t.name) || s(t);
      }),
      n
    );
  }
  var gi = { placement: "bottom", modifiers: [], strategy: "absolute" };
  function _i() {
    for (var t = arguments.length, e = new Array(t), i = 0; i < t; i++)
      e[i] = arguments[i];
    return !e.some(function (t) {
      return !(t && "function" == typeof t.getBoundingClientRect);
    });
  }
  function bi(t) {
    void 0 === t && (t = {});
    var e = t,
      i = e.defaultModifiers,
      n = void 0 === i ? [] : i,
      s = e.defaultOptions,
      o = void 0 === s ? gi : s;
    return function (t, e, i) {
      void 0 === i && (i = o);
      var s,
        r,
        a = {
          placement: "bottom",
          orderedModifiers: [],
          options: Object.assign({}, gi, o),
          modifiersData: {},
          elements: { reference: t, popper: e },
          attributes: {},
          styles: {},
        },
        l = [],
        c = !1,
        h = {
          state: a,
          setOptions: function (i) {
            var s = "function" == typeof i ? i(a.options) : i;
            (d(),
              (a.options = Object.assign({}, o, a.options, s)),
              (a.scrollParents = {
                reference: _e(t)
                  ? ei(t)
                  : t.contextElement
                    ? ei(t.contextElement)
                    : [],
                popper: ei(e),
              }));
            var r,
              c,
              u = (function (t) {
                var e = mi(t);
                return pe.reduce(function (t, i) {
                  return t.concat(
                    e.filter(function (t) {
                      return t.phase === i;
                    }),
                  );
                }, []);
              })(
                ((r = [].concat(n, a.options.modifiers)),
                (c = r.reduce(function (t, e) {
                  var i = t[e.name];
                  return (
                    (t[e.name] = i
                      ? Object.assign({}, i, e, {
                          options: Object.assign({}, i.options, e.options),
                          data: Object.assign({}, i.data, e.data),
                        })
                      : e),
                    t
                  );
                }, {})),
                Object.keys(c).map(function (t) {
                  return c[t];
                })),
              );
            return (
              (a.orderedModifiers = u.filter(function (t) {
                return t.enabled;
              })),
              a.orderedModifiers.forEach(function (t) {
                var e = t.name,
                  i = t.options,
                  n = void 0 === i ? {} : i,
                  s = t.effect;
                if ("function" == typeof s) {
                  var o = s({ state: a, name: e, instance: h, options: n });
                  l.push(o || function () {});
                }
              }),
              h.update()
            );
          },
          forceUpdate: function () {
            if (!c) {
              var t = a.elements,
                e = t.reference,
                i = t.popper;
              if (_i(e, i)) {
                ((a.rects = {
                  reference: pi(e, Pe(i), "fixed" === a.options.strategy),
                  popper: ke(i),
                }),
                  (a.reset = !1),
                  (a.placement = a.options.placement),
                  a.orderedModifiers.forEach(function (t) {
                    return (a.modifiersData[t.name] = Object.assign(
                      {},
                      t.data,
                    ));
                  }));
                for (var n = 0; n < a.orderedModifiers.length; n++)
                  if (!0 !== a.reset) {
                    var s = a.orderedModifiers[n],
                      o = s.fn,
                      r = s.options,
                      l = void 0 === r ? {} : r,
                      d = s.name;
                    "function" == typeof o &&
                      (a =
                        o({ state: a, options: l, name: d, instance: h }) || a);
                  } else ((a.reset = !1), (n = -1));
              }
            }
          },
          update:
            ((s = function () {
              return new Promise(function (t) {
                (h.forceUpdate(), t(a));
              });
            }),
            function () {
              return (
                r ||
                  (r = new Promise(function (t) {
                    Promise.resolve().then(function () {
                      ((r = void 0), t(s()));
                    });
                  })),
                r
              );
            }),
          destroy: function () {
            (d(), (c = !0));
          },
        };
      if (!_i(t, e)) return h;
      function d() {
        (l.forEach(function (t) {
          return t();
        }),
          (l = []));
      }
      return (
        h.setOptions(i).then(function (t) {
          !c && i.onFirstUpdate && i.onFirstUpdate(t);
        }),
        h
      );
    };
  }
  var vi = bi(),
    yi = bi({ defaultModifiers: [Ke, ui, qe, ye] }),
    wi = bi({ defaultModifiers: [Ke, ui, qe, ye, di, ai, fi, We, hi] });
  const Ai = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          afterMain: he,
          afterRead: ae,
          afterWrite: fe,
          applyStyles: ye,
          arrow: We,
          auto: Yt,
          basePlacements: Ut,
          beforeMain: le,
          beforeRead: oe,
          beforeWrite: de,
          bottom: Kt,
          clippingParents: Zt,
          computeStyles: qe,
          createPopper: wi,
          createPopperBase: vi,
          createPopperLite: yi,
          detectOverflow: oi,
          end: Jt,
          eventListeners: Ke,
          flip: ai,
          hide: hi,
          left: Xt,
          main: ce,
          modifierPhases: pe,
          offset: di,
          placements: se,
          popper: ee,
          popperGenerator: bi,
          popperOffsets: ui,
          preventOverflow: fi,
          read: re,
          reference: ie,
          right: Qt,
          start: Gt,
          top: Vt,
          variationPlacements: ne,
          viewport: te,
          write: ue,
        },
        Symbol.toStringTag,
        { value: "Module" },
      ),
    ),
    Ei = "dropdown",
    Ti = ".bs.dropdown",
    Ci = ".data-api",
    Oi = "ArrowUp",
    xi = "ArrowDown",
    ki = `hide${Ti}`,
    Li = `hidden${Ti}`,
    Si = `show${Ti}`,
    Di = `shown${Ti}`,
    $i = `click${Ti}${Ci}`,
    Ii = `keydown${Ti}${Ci}`,
    Ni = `keyup${Ti}${Ci}`,
    Pi = "show",
    ji = '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)',
    Mi = `${ji}.${Pi}`,
    Fi = ".dropdown-menu",
    Hi = m() ? "top-end" : "top-start",
    Wi = m() ? "top-start" : "top-end",
    Bi = m() ? "bottom-end" : "bottom-start",
    zi = m() ? "bottom-start" : "bottom-end",
    Ri = m() ? "left-start" : "right-start",
    qi = m() ? "right-start" : "left-start",
    Vi = {
      autoClose: !0,
      boundary: "clippingParents",
      display: "dynamic",
      offset: [0, 2],
      popperConfig: null,
      reference: "toggle",
    },
    Ki = {
      autoClose: "(boolean|string)",
      boundary: "(string|element)",
      display: "string",
      offset: "(array|string|function)",
      popperConfig: "(null|object|function)",
      reference: "(string|element|object)",
    };
  class Qi extends B {
    constructor(t, e) {
      (super(t, e),
        (this._popper = null),
        (this._parent = this._element.parentNode),
        (this._menu =
          R.next(this._element, Fi)[0] ||
          R.prev(this._element, Fi)[0] ||
          R.findOne(Fi, this._parent)),
        (this._inNavbar = this._detectNavbar()));
    }
    static get Default() {
      return Vi;
    }
    static get DefaultType() {
      return Ki;
    }
    static get NAME() {
      return Ei;
    }
    toggle() {
      return this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (c(this._element) || this._isShown()) return;
      const t = { relatedTarget: this._element };
      if (!P.trigger(this._element, Si, t).defaultPrevented) {
        if (
          (this._createPopper(),
          "ontouchstart" in document.documentElement &&
            !this._parent.closest(".navbar-nav"))
        )
          for (const t of [].concat(...document.body.children))
            P.on(t, "mouseover", d);
        (this._element.focus(),
          this._element.setAttribute("aria-expanded", !0),
          this._menu.classList.add(Pi),
          this._element.classList.add(Pi),
          P.trigger(this._element, Di, t));
      }
    }
    hide() {
      if (c(this._element) || !this._isShown()) return;
      const t = { relatedTarget: this._element };
      this._completeHide(t);
    }
    dispose() {
      (this._popper && this._popper.destroy(), super.dispose());
    }
    update() {
      ((this._inNavbar = this._detectNavbar()),
        this._popper && this._popper.update());
    }
    _completeHide(t) {
      if (!P.trigger(this._element, ki, t).defaultPrevented) {
        if ("ontouchstart" in document.documentElement)
          for (const t of [].concat(...document.body.children))
            P.off(t, "mouseover", d);
        (this._popper && this._popper.destroy(),
          this._menu.classList.remove(Pi),
          this._element.classList.remove(Pi),
          this._element.setAttribute("aria-expanded", "false"),
          H.removeDataAttribute(this._menu, "popper"),
          P.trigger(this._element, Li, t));
      }
    }
    _getConfig(t) {
      if (
        "object" == typeof (t = super._getConfig(t)).reference &&
        !r(t.reference) &&
        "function" != typeof t.reference.getBoundingClientRect
      )
        throw new TypeError(
          `${Ei.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`,
        );
      return t;
    }
    _createPopper() {
      if (void 0 === Ai)
        throw new TypeError(
          "Bootstrap's dropdowns require Popper (https://popper.js.org/docs/v2/)",
        );
      let t = this._element;
      "parent" === this._config.reference
        ? (t = this._parent)
        : r(this._config.reference)
          ? (t = a(this._config.reference))
          : "object" == typeof this._config.reference &&
            (t = this._config.reference);
      const e = this._getPopperConfig();
      this._popper = wi(t, this._menu, e);
    }
    _isShown() {
      return this._menu.classList.contains(Pi);
    }
    _getPlacement() {
      const t = this._parent;
      if (t.classList.contains("dropend")) return Ri;
      if (t.classList.contains("dropstart")) return qi;
      if (t.classList.contains("dropup-center")) return "top";
      if (t.classList.contains("dropdown-center")) return "bottom";
      const e =
        "end" ===
        getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
      return t.classList.contains("dropup") ? (e ? Wi : Hi) : e ? zi : Bi;
    }
    _detectNavbar() {
      return null !== this._element.closest(".navbar");
    }
    _getOffset() {
      const { offset: t } = this._config;
      return "string" == typeof t
        ? t.split(",").map((t) => Number.parseInt(t, 10))
        : "function" == typeof t
          ? (e) => t(e, this._element)
          : t;
    }
    _getPopperConfig() {
      const t = {
        placement: this._getPlacement(),
        modifiers: [
          {
            name: "preventOverflow",
            options: { boundary: this._config.boundary },
          },
          { name: "offset", options: { offset: this._getOffset() } },
        ],
      };
      return (
        (this._inNavbar || "static" === this._config.display) &&
          (H.setDataAttribute(this._menu, "popper", "static"),
          (t.modifiers = [{ name: "applyStyles", enabled: !1 }])),
        { ...t, ..._(this._config.popperConfig, [void 0, t]) }
      );
    }
    _selectMenuItem({ key: t, target: e }) {
      const i = R.find(
        ".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)",
        this._menu,
      ).filter((t) => l(t));
      i.length && v(i, e, t === xi, !i.includes(e)).focus();
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = Qi.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
          e[t]();
        }
      });
    }
    static clearMenus(t) {
      if (2 === t.button || ("keyup" === t.type && "Tab" !== t.key)) return;
      const e = R.find(Mi);
      for (const i of e) {
        const e = Qi.getInstance(i);
        if (!e || !1 === e._config.autoClose) continue;
        const n = t.composedPath(),
          s = n.includes(e._menu);
        if (
          n.includes(e._element) ||
          ("inside" === e._config.autoClose && !s) ||
          ("outside" === e._config.autoClose && s)
        )
          continue;
        if (
          e._menu.contains(t.target) &&
          (("keyup" === t.type && "Tab" === t.key) ||
            /input|select|option|textarea|form/i.test(t.target.tagName))
        )
          continue;
        const o = { relatedTarget: e._element };
        ("click" === t.type && (o.clickEvent = t), e._completeHide(o));
      }
    }
    static dataApiKeydownHandler(t) {
      const e = /input|textarea/i.test(t.target.tagName),
        i = "Escape" === t.key,
        n = [Oi, xi].includes(t.key);
      if (!n && !i) return;
      if (e && !i) return;
      t.preventDefault();
      const s = this.matches(ji)
          ? this
          : R.prev(this, ji)[0] ||
            R.next(this, ji)[0] ||
            R.findOne(ji, t.delegateTarget.parentNode),
        o = Qi.getOrCreateInstance(s);
      if (n) return (t.stopPropagation(), o.show(), void o._selectMenuItem(t));
      o._isShown() && (t.stopPropagation(), o.hide(), s.focus());
    }
  }
  (P.on(document, Ii, ji, Qi.dataApiKeydownHandler),
    P.on(document, Ii, Fi, Qi.dataApiKeydownHandler),
    P.on(document, $i, Qi.clearMenus),
    P.on(document, Ni, Qi.clearMenus),
    P.on(document, $i, ji, function (t) {
      (t.preventDefault(), Qi.getOrCreateInstance(this).toggle());
    }),
    g(Qi));
  const Xi = "backdrop",
    Yi = "show",
    Ui = `mousedown.bs.${Xi}`,
    Gi = {
      className: "modal-backdrop",
      clickCallback: null,
      isAnimated: !1,
      isVisible: !0,
      rootElement: "body",
    },
    Ji = {
      className: "string",
      clickCallback: "(function|null)",
      isAnimated: "boolean",
      isVisible: "boolean",
      rootElement: "(element|string)",
    };
  class Zi extends W {
    constructor(t) {
      (super(),
        (this._config = this._getConfig(t)),
        (this._isAppended = !1),
        (this._element = null));
    }
    static get Default() {
      return Gi;
    }
    static get DefaultType() {
      return Ji;
    }
    static get NAME() {
      return Xi;
    }
    show(t) {
      if (!this._config.isVisible) return void _(t);
      this._append();
      const e = this._getElement();
      (this._config.isAnimated && u(e),
        e.classList.add(Yi),
        this._emulateAnimation(() => {
          _(t);
        }));
    }
    hide(t) {
      this._config.isVisible
        ? (this._getElement().classList.remove(Yi),
          this._emulateAnimation(() => {
            (this.dispose(), _(t));
          }))
        : _(t);
    }
    dispose() {
      this._isAppended &&
        (P.off(this._element, Ui),
        this._element.remove(),
        (this._isAppended = !1));
    }
    _getElement() {
      if (!this._element) {
        const t = document.createElement("div");
        ((t.className = this._config.className),
          this._config.isAnimated && t.classList.add("fade"),
          (this._element = t));
      }
      return this._element;
    }
    _configAfterMerge(t) {
      return ((t.rootElement = a(t.rootElement)), t);
    }
    _append() {
      if (this._isAppended) return;
      const t = this._getElement();
      (this._config.rootElement.append(t),
        P.on(t, Ui, () => {
          _(this._config.clickCallback);
        }),
        (this._isAppended = !0));
    }
    _emulateAnimation(t) {
      b(t, this._getElement(), this._config.isAnimated);
    }
  }
  const tn = ".bs.focustrap",
    en = `focusin${tn}`,
    nn = `keydown.tab${tn}`,
    sn = "backward",
    on = { autofocus: !0, trapElement: null },
    rn = { autofocus: "boolean", trapElement: "element" };
  class an extends W {
    constructor(t) {
      (super(),
        (this._config = this._getConfig(t)),
        (this._isActive = !1),
        (this._lastTabNavDirection = null));
    }
    static get Default() {
      return on;
    }
    static get DefaultType() {
      return rn;
    }
    static get NAME() {
      return "focustrap";
    }
    activate() {
      this._isActive ||
        (this._config.autofocus && this._config.trapElement.focus(),
        P.off(document, tn),
        P.on(document, en, (t) => this._handleFocusin(t)),
        P.on(document, nn, (t) => this._handleKeydown(t)),
        (this._isActive = !0));
    }
    deactivate() {
      this._isActive && ((this._isActive = !1), P.off(document, tn));
    }
    _handleFocusin(t) {
      const { trapElement: e } = this._config;
      if (t.target === document || t.target === e || e.contains(t.target))
        return;
      const i = R.focusableChildren(e);
      0 === i.length
        ? e.focus()
        : this._lastTabNavDirection === sn
          ? i[i.length - 1].focus()
          : i[0].focus();
    }
    _handleKeydown(t) {
      "Tab" === t.key &&
        (this._lastTabNavDirection = t.shiftKey ? sn : "forward");
    }
  }
  const ln = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
    cn = ".sticky-top",
    hn = "padding-right",
    dn = "margin-right";
  class un {
    constructor() {
      this._element = document.body;
    }
    getWidth() {
      const t = document.documentElement.clientWidth;
      return Math.abs(window.innerWidth - t);
    }
    hide() {
      const t = this.getWidth();
      (this._disableOverFlow(),
        this._setElementAttributes(this._element, hn, (e) => e + t),
        this._setElementAttributes(ln, hn, (e) => e + t),
        this._setElementAttributes(cn, dn, (e) => e - t));
    }
    reset() {
      (this._resetElementAttributes(this._element, "overflow"),
        this._resetElementAttributes(this._element, hn),
        this._resetElementAttributes(ln, hn),
        this._resetElementAttributes(cn, dn));
    }
    isOverflowing() {
      return this.getWidth() > 0;
    }
    _disableOverFlow() {
      (this._saveInitialAttribute(this._element, "overflow"),
        (this._element.style.overflow = "hidden"));
    }
    _setElementAttributes(t, e, i) {
      const n = this.getWidth();
      this._applyManipulationCallback(t, (t) => {
        if (t !== this._element && window.innerWidth > t.clientWidth + n)
          return;
        this._saveInitialAttribute(t, e);
        const s = window.getComputedStyle(t).getPropertyValue(e);
        t.style.setProperty(e, `${i(Number.parseFloat(s))}px`);
      });
    }
    _saveInitialAttribute(t, e) {
      const i = t.style.getPropertyValue(e);
      i && H.setDataAttribute(t, e, i);
    }
    _resetElementAttributes(t, e) {
      this._applyManipulationCallback(t, (t) => {
        const i = H.getDataAttribute(t, e);
        null !== i
          ? (H.removeDataAttribute(t, e), t.style.setProperty(e, i))
          : t.style.removeProperty(e);
      });
    }
    _applyManipulationCallback(t, e) {
      if (r(t)) e(t);
      else for (const i of R.find(t, this._element)) e(i);
    }
  }
  const fn = ".bs.modal",
    pn = `hide${fn}`,
    mn = `hidePrevented${fn}`,
    gn = `hidden${fn}`,
    _n = `show${fn}`,
    bn = `shown${fn}`,
    vn = `resize${fn}`,
    yn = `click.dismiss${fn}`,
    wn = `mousedown.dismiss${fn}`,
    An = `keydown.dismiss${fn}`,
    En = `click${fn}.data-api`,
    Tn = "modal-open",
    Cn = "show",
    On = "modal-static",
    xn = { backdrop: !0, focus: !0, keyboard: !0 },
    kn = {
      backdrop: "(boolean|string)",
      focus: "boolean",
      keyboard: "boolean",
    };
  class Ln extends B {
    constructor(t, e) {
      (super(t, e),
        (this._dialog = R.findOne(".modal-dialog", this._element)),
        (this._backdrop = this._initializeBackDrop()),
        (this._focustrap = this._initializeFocusTrap()),
        (this._isShown = !1),
        (this._isTransitioning = !1),
        (this._scrollBar = new un()),
        this._addEventListeners());
    }
    static get Default() {
      return xn;
    }
    static get DefaultType() {
      return kn;
    }
    static get NAME() {
      return "modal";
    }
    toggle(t) {
      return this._isShown ? this.hide() : this.show(t);
    }
    show(t) {
      this._isShown ||
        this._isTransitioning ||
        P.trigger(this._element, _n, { relatedTarget: t }).defaultPrevented ||
        ((this._isShown = !0),
        (this._isTransitioning = !0),
        this._scrollBar.hide(),
        document.body.classList.add(Tn),
        this._adjustDialog(),
        this._backdrop.show(() => this._showElement(t)));
    }
    hide() {
      this._isShown &&
        !this._isTransitioning &&
        (P.trigger(this._element, pn).defaultPrevented ||
          ((this._isShown = !1),
          (this._isTransitioning = !0),
          this._focustrap.deactivate(),
          this._element.classList.remove(Cn),
          this._queueCallback(
            () => this._hideModal(),
            this._element,
            this._isAnimated(),
          )));
    }
    dispose() {
      (P.off(window, fn),
        P.off(this._dialog, fn),
        this._backdrop.dispose(),
        this._focustrap.deactivate(),
        super.dispose());
    }
    handleUpdate() {
      this._adjustDialog();
    }
    _initializeBackDrop() {
      return new Zi({
        isVisible: Boolean(this._config.backdrop),
        isAnimated: this._isAnimated(),
      });
    }
    _initializeFocusTrap() {
      return new an({ trapElement: this._element });
    }
    _showElement(t) {
      (document.body.contains(this._element) ||
        document.body.append(this._element),
        (this._element.style.display = "block"),
        this._element.removeAttribute("aria-hidden"),
        this._element.setAttribute("aria-modal", !0),
        this._element.setAttribute("role", "dialog"),
        (this._element.scrollTop = 0));
      const e = R.findOne(".modal-body", this._dialog);
      (e && (e.scrollTop = 0),
        u(this._element),
        this._element.classList.add(Cn),
        this._queueCallback(
          () => {
            (this._config.focus && this._focustrap.activate(),
              (this._isTransitioning = !1),
              P.trigger(this._element, bn, { relatedTarget: t }));
          },
          this._dialog,
          this._isAnimated(),
        ));
    }
    _addEventListeners() {
      (P.on(this._element, An, (t) => {
        "Escape" === t.key &&
          (this._config.keyboard
            ? this.hide()
            : this._triggerBackdropTransition());
      }),
        P.on(window, vn, () => {
          this._isShown && !this._isTransitioning && this._adjustDialog();
        }),
        P.on(this._element, wn, (t) => {
          P.one(this._element, yn, (e) => {
            this._element === t.target &&
              this._element === e.target &&
              ("static" !== this._config.backdrop
                ? this._config.backdrop && this.hide()
                : this._triggerBackdropTransition());
          });
        }));
    }
    _hideModal() {
      ((this._element.style.display = "none"),
        this._element.setAttribute("aria-hidden", !0),
        this._element.removeAttribute("aria-modal"),
        this._element.removeAttribute("role"),
        (this._isTransitioning = !1),
        this._backdrop.hide(() => {
          (document.body.classList.remove(Tn),
            this._resetAdjustments(),
            this._scrollBar.reset(),
            P.trigger(this._element, gn));
        }));
    }
    _isAnimated() {
      return this._element.classList.contains("fade");
    }
    _triggerBackdropTransition() {
      if (P.trigger(this._element, mn).defaultPrevented) return;
      const t =
          this._element.scrollHeight > document.documentElement.clientHeight,
        e = this._element.style.overflowY;
      "hidden" === e ||
        this._element.classList.contains(On) ||
        (t || (this._element.style.overflowY = "hidden"),
        this._element.classList.add(On),
        this._queueCallback(() => {
          (this._element.classList.remove(On),
            this._queueCallback(() => {
              this._element.style.overflowY = e;
            }, this._dialog));
        }, this._dialog),
        this._element.focus());
    }
    _adjustDialog() {
      const t =
          this._element.scrollHeight > document.documentElement.clientHeight,
        e = this._scrollBar.getWidth(),
        i = e > 0;
      if (i && !t) {
        const t = m() ? "paddingLeft" : "paddingRight";
        this._element.style[t] = `${e}px`;
      }
      if (!i && t) {
        const t = m() ? "paddingRight" : "paddingLeft";
        this._element.style[t] = `${e}px`;
      }
    }
    _resetAdjustments() {
      ((this._element.style.paddingLeft = ""),
        (this._element.style.paddingRight = ""));
    }
    static jQueryInterface(t, e) {
      return this.each(function () {
        const i = Ln.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === i[t]) throw new TypeError(`No method named "${t}"`);
          i[t](e);
        }
      });
    }
  }
  (P.on(document, En, '[data-bs-toggle="modal"]', function (t) {
    const e = R.getElementFromSelector(this);
    (["A", "AREA"].includes(this.tagName) && t.preventDefault(),
      P.one(e, _n, (t) => {
        t.defaultPrevented ||
          P.one(e, gn, () => {
            l(this) && this.focus();
          });
      }));
    const i = R.findOne(".modal.show");
    (i && Ln.getInstance(i).hide(), Ln.getOrCreateInstance(e).toggle(this));
  }),
    q(Ln),
    g(Ln));
  const Sn = ".bs.offcanvas",
    Dn = ".data-api",
    $n = `load${Sn}${Dn}`,
    In = "show",
    Nn = "showing",
    Pn = "hiding",
    jn = ".offcanvas.show",
    Mn = `show${Sn}`,
    Fn = `shown${Sn}`,
    Hn = `hide${Sn}`,
    Wn = `hidePrevented${Sn}`,
    Bn = `hidden${Sn}`,
    zn = `resize${Sn}`,
    Rn = `click${Sn}${Dn}`,
    qn = `keydown.dismiss${Sn}`,
    Vn = { backdrop: !0, keyboard: !0, scroll: !1 },
    Kn = {
      backdrop: "(boolean|string)",
      keyboard: "boolean",
      scroll: "boolean",
    };
  class Qn extends B {
    constructor(t, e) {
      (super(t, e),
        (this._isShown = !1),
        (this._backdrop = this._initializeBackDrop()),
        (this._focustrap = this._initializeFocusTrap()),
        this._addEventListeners());
    }
    static get Default() {
      return Vn;
    }
    static get DefaultType() {
      return Kn;
    }
    static get NAME() {
      return "offcanvas";
    }
    toggle(t) {
      return this._isShown ? this.hide() : this.show(t);
    }
    show(t) {
      this._isShown ||
        P.trigger(this._element, Mn, { relatedTarget: t }).defaultPrevented ||
        ((this._isShown = !0),
        this._backdrop.show(),
        this._config.scroll || new un().hide(),
        this._element.setAttribute("aria-modal", !0),
        this._element.setAttribute("role", "dialog"),
        this._element.classList.add(Nn),
        this._queueCallback(
          () => {
            ((this._config.scroll && !this._config.backdrop) ||
              this._focustrap.activate(),
              this._element.classList.add(In),
              this._element.classList.remove(Nn),
              P.trigger(this._element, Fn, { relatedTarget: t }));
          },
          this._element,
          !0,
        ));
    }
    hide() {
      this._isShown &&
        (P.trigger(this._element, Hn).defaultPrevented ||
          (this._focustrap.deactivate(),
          this._element.blur(),
          (this._isShown = !1),
          this._element.classList.add(Pn),
          this._backdrop.hide(),
          this._queueCallback(
            () => {
              (this._element.classList.remove(In, Pn),
                this._element.removeAttribute("aria-modal"),
                this._element.removeAttribute("role"),
                this._config.scroll || new un().reset(),
                P.trigger(this._element, Bn));
            },
            this._element,
            !0,
          )));
    }
    dispose() {
      (this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose());
    }
    _initializeBackDrop() {
      const t = Boolean(this._config.backdrop);
      return new Zi({
        className: "offcanvas-backdrop",
        isVisible: t,
        isAnimated: !0,
        rootElement: this._element.parentNode,
        clickCallback: t
          ? () => {
              "static" !== this._config.backdrop
                ? this.hide()
                : P.trigger(this._element, Wn);
            }
          : null,
      });
    }
    _initializeFocusTrap() {
      return new an({ trapElement: this._element });
    }
    _addEventListeners() {
      P.on(this._element, qn, (t) => {
        "Escape" === t.key &&
          (this._config.keyboard ? this.hide() : P.trigger(this._element, Wn));
      });
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = Qn.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === e[t] || t.startsWith("_") || "constructor" === t)
            throw new TypeError(`No method named "${t}"`);
          e[t](this);
        }
      });
    }
  }
  (P.on(document, Rn, '[data-bs-toggle="offcanvas"]', function (t) {
    const e = R.getElementFromSelector(this);
    if ((["A", "AREA"].includes(this.tagName) && t.preventDefault(), c(this)))
      return;
    P.one(e, Bn, () => {
      l(this) && this.focus();
    });
    const i = R.findOne(jn);
    (i && i !== e && Qn.getInstance(i).hide(),
      Qn.getOrCreateInstance(e).toggle(this));
  }),
    P.on(window, $n, () => {
      for (const t of R.find(jn)) Qn.getOrCreateInstance(t).show();
    }),
    P.on(window, zn, () => {
      for (const t of R.find("[aria-modal][class*=show][class*=offcanvas-]"))
        "fixed" !== getComputedStyle(t).position &&
          Qn.getOrCreateInstance(t).hide();
    }),
    q(Qn),
    g(Qn));
  const Xn = {
      "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
      a: ["target", "href", "title", "rel"],
      area: [],
      b: [],
      br: [],
      col: [],
      code: [],
      dd: [],
      div: [],
      dl: [],
      dt: [],
      em: [],
      hr: [],
      h1: [],
      h2: [],
      h3: [],
      h4: [],
      h5: [],
      h6: [],
      i: [],
      img: ["src", "srcset", "alt", "title", "width", "height"],
      li: [],
      ol: [],
      p: [],
      pre: [],
      s: [],
      small: [],
      span: [],
      sub: [],
      sup: [],
      strong: [],
      u: [],
      ul: [],
    },
    Yn = new Set([
      "background",
      "cite",
      "href",
      "itemtype",
      "longdesc",
      "poster",
      "src",
      "xlink:href",
    ]),
    Un = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i,
    Gn = (t, e) => {
      const i = t.nodeName.toLowerCase();
      return e.includes(i)
        ? !Yn.has(i) || Boolean(Un.test(t.nodeValue))
        : e.filter((t) => t instanceof RegExp).some((t) => t.test(i));
    },
    Jn = {
      allowList: Xn,
      content: {},
      extraClass: "",
      html: !1,
      sanitize: !0,
      sanitizeFn: null,
      template: "<div></div>",
    },
    Zn = {
      allowList: "object",
      content: "object",
      extraClass: "(string|function)",
      html: "boolean",
      sanitize: "boolean",
      sanitizeFn: "(null|function)",
      template: "string",
    },
    ts = {
      entry: "(string|element|function|null)",
      selector: "(string|element)",
    };
  class es extends W {
    constructor(t) {
      (super(), (this._config = this._getConfig(t)));
    }
    static get Default() {
      return Jn;
    }
    static get DefaultType() {
      return Zn;
    }
    static get NAME() {
      return "TemplateFactory";
    }
    getContent() {
      return Object.values(this._config.content)
        .map((t) => this._resolvePossibleFunction(t))
        .filter(Boolean);
    }
    hasContent() {
      return this.getContent().length > 0;
    }
    changeContent(t) {
      return (
        this._checkContent(t),
        (this._config.content = { ...this._config.content, ...t }),
        this
      );
    }
    toHtml() {
      const t = document.createElement("div");
      t.innerHTML = this._maybeSanitize(this._config.template);
      for (const [e, i] of Object.entries(this._config.content))
        this._setContent(t, i, e);
      const e = t.children[0],
        i = this._resolvePossibleFunction(this._config.extraClass);
      return (i && e.classList.add(...i.split(" ")), e);
    }
    _typeCheckConfig(t) {
      (super._typeCheckConfig(t), this._checkContent(t.content));
    }
    _checkContent(t) {
      for (const [e, i] of Object.entries(t))
        super._typeCheckConfig({ selector: e, entry: i }, ts);
    }
    _setContent(t, e, i) {
      const n = R.findOne(i, t);
      n &&
        ((e = this._resolvePossibleFunction(e))
          ? r(e)
            ? this._putElementInTemplate(a(e), n)
            : this._config.html
              ? (n.innerHTML = this._maybeSanitize(e))
              : (n.textContent = e)
          : n.remove());
    }
    _maybeSanitize(t) {
      return this._config.sanitize
        ? (function (t, e, i) {
            if (!t.length) return t;
            if (i && "function" == typeof i) return i(t);
            const n = new window.DOMParser().parseFromString(t, "text/html"),
              s = [].concat(...n.body.querySelectorAll("*"));
            for (const t of s) {
              const i = t.nodeName.toLowerCase();
              if (!Object.keys(e).includes(i)) {
                t.remove();
                continue;
              }
              const n = [].concat(...t.attributes),
                s = [].concat(e["*"] || [], e[i] || []);
              for (const e of n) Gn(e, s) || t.removeAttribute(e.nodeName);
            }
            return n.body.innerHTML;
          })(t, this._config.allowList, this._config.sanitizeFn)
        : t;
    }
    _resolvePossibleFunction(t) {
      return _(t, [void 0, this]);
    }
    _putElementInTemplate(t, e) {
      if (this._config.html) return ((e.innerHTML = ""), void e.append(t));
      e.textContent = t.textContent;
    }
  }
  const is = new Set(["sanitize", "allowList", "sanitizeFn"]),
    ns = "fade",
    ss = "show",
    os = ".tooltip-inner",
    rs = ".modal",
    as = "hide.bs.modal",
    ls = "hover",
    cs = "focus",
    hs = "click",
    ds = {
      AUTO: "auto",
      TOP: "top",
      RIGHT: m() ? "left" : "right",
      BOTTOM: "bottom",
      LEFT: m() ? "right" : "left",
    },
    us = {
      allowList: Xn,
      animation: !0,
      boundary: "clippingParents",
      container: !1,
      customClass: "",
      delay: 0,
      fallbackPlacements: ["top", "right", "bottom", "left"],
      html: !1,
      offset: [0, 6],
      placement: "top",
      popperConfig: null,
      sanitize: !0,
      sanitizeFn: null,
      selector: !1,
      template:
        '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
      title: "",
      trigger: "hover focus",
    },
    fs = {
      allowList: "object",
      animation: "boolean",
      boundary: "(string|element)",
      container: "(string|element|boolean)",
      customClass: "(string|function)",
      delay: "(number|object)",
      fallbackPlacements: "array",
      html: "boolean",
      offset: "(array|string|function)",
      placement: "(string|function)",
      popperConfig: "(null|object|function)",
      sanitize: "boolean",
      sanitizeFn: "(null|function)",
      selector: "(string|boolean)",
      template: "string",
      title: "(string|element|function)",
      trigger: "string",
    };
  class ps extends B {
    constructor(t, e) {
      if (void 0 === Ai)
        throw new TypeError(
          "Bootstrap's tooltips require Popper (https://popper.js.org/docs/v2/)",
        );
      (super(t, e),
        (this._isEnabled = !0),
        (this._timeout = 0),
        (this._isHovered = null),
        (this._activeTrigger = {}),
        (this._popper = null),
        (this._templateFactory = null),
        (this._newContent = null),
        (this.tip = null),
        this._setListeners(),
        this._config.selector || this._fixTitle());
    }
    static get Default() {
      return us;
    }
    static get DefaultType() {
      return fs;
    }
    static get NAME() {
      return "tooltip";
    }
    enable() {
      this._isEnabled = !0;
    }
    disable() {
      this._isEnabled = !1;
    }
    toggleEnabled() {
      this._isEnabled = !this._isEnabled;
    }
    toggle() {
      this._isEnabled && (this._isShown() ? this._leave() : this._enter());
    }
    dispose() {
      (clearTimeout(this._timeout),
        P.off(this._element.closest(rs), as, this._hideModalHandler),
        this._element.getAttribute("data-bs-original-title") &&
          this._element.setAttribute(
            "title",
            this._element.getAttribute("data-bs-original-title"),
          ),
        this._disposePopper(),
        super.dispose());
    }
    show() {
      if ("none" === this._element.style.display)
        throw new Error("Please use show on visible elements");
      if (!this._isWithContent() || !this._isEnabled) return;
      const t = P.trigger(this._element, this.constructor.eventName("show")),
        e = (
          h(this._element) || this._element.ownerDocument.documentElement
        ).contains(this._element);
      if (t.defaultPrevented || !e) return;
      this._disposePopper();
      const i = this._getTipElement();
      this._element.setAttribute("aria-describedby", i.getAttribute("id"));
      const { container: n } = this._config;
      if (
        (this._element.ownerDocument.documentElement.contains(this.tip) ||
          (n.append(i),
          P.trigger(this._element, this.constructor.eventName("inserted"))),
        (this._popper = this._createPopper(i)),
        i.classList.add(ss),
        "ontouchstart" in document.documentElement)
      )
        for (const t of [].concat(...document.body.children))
          P.on(t, "mouseover", d);
      this._queueCallback(
        () => {
          (P.trigger(this._element, this.constructor.eventName("shown")),
            !1 === this._isHovered && this._leave(),
            (this._isHovered = !1));
        },
        this.tip,
        this._isAnimated(),
      );
    }
    hide() {
      if (
        this._isShown() &&
        !P.trigger(this._element, this.constructor.eventName("hide"))
          .defaultPrevented
      ) {
        if (
          (this._getTipElement().classList.remove(ss),
          "ontouchstart" in document.documentElement)
        )
          for (const t of [].concat(...document.body.children))
            P.off(t, "mouseover", d);
        ((this._activeTrigger[hs] = !1),
          (this._activeTrigger[cs] = !1),
          (this._activeTrigger[ls] = !1),
          (this._isHovered = null),
          this._queueCallback(
            () => {
              this._isWithActiveTrigger() ||
                (this._isHovered || this._disposePopper(),
                this._element.removeAttribute("aria-describedby"),
                P.trigger(this._element, this.constructor.eventName("hidden")));
            },
            this.tip,
            this._isAnimated(),
          ));
      }
    }
    update() {
      this._popper && this._popper.update();
    }
    _isWithContent() {
      return Boolean(this._getTitle());
    }
    _getTipElement() {
      return (
        this.tip ||
          (this.tip = this._createTipElement(
            this._newContent || this._getContentForTemplate(),
          )),
        this.tip
      );
    }
    _createTipElement(t) {
      const e = this._getTemplateFactory(t).toHtml();
      if (!e) return null;
      (e.classList.remove(ns, ss),
        e.classList.add(`bs-${this.constructor.NAME}-auto`));
      const i = ((t) => {
        do {
          t += Math.floor(1e6 * Math.random());
        } while (document.getElementById(t));
        return t;
      })(this.constructor.NAME).toString();
      return (
        e.setAttribute("id", i),
        this._isAnimated() && e.classList.add(ns),
        e
      );
    }
    setContent(t) {
      ((this._newContent = t),
        this._isShown() && (this._disposePopper(), this.show()));
    }
    _getTemplateFactory(t) {
      return (
        this._templateFactory
          ? this._templateFactory.changeContent(t)
          : (this._templateFactory = new es({
              ...this._config,
              content: t,
              extraClass: this._resolvePossibleFunction(
                this._config.customClass,
              ),
            })),
        this._templateFactory
      );
    }
    _getContentForTemplate() {
      return { [os]: this._getTitle() };
    }
    _getTitle() {
      return (
        this._resolvePossibleFunction(this._config.title) ||
        this._element.getAttribute("data-bs-original-title")
      );
    }
    _initializeOnDelegatedTarget(t) {
      return this.constructor.getOrCreateInstance(
        t.delegateTarget,
        this._getDelegateConfig(),
      );
    }
    _isAnimated() {
      return (
        this._config.animation || (this.tip && this.tip.classList.contains(ns))
      );
    }
    _isShown() {
      return this.tip && this.tip.classList.contains(ss);
    }
    _createPopper(t) {
      const e = _(this._config.placement, [this, t, this._element]),
        i = ds[e.toUpperCase()];
      return wi(this._element, t, this._getPopperConfig(i));
    }
    _getOffset() {
      const { offset: t } = this._config;
      return "string" == typeof t
        ? t.split(",").map((t) => Number.parseInt(t, 10))
        : "function" == typeof t
          ? (e) => t(e, this._element)
          : t;
    }
    _resolvePossibleFunction(t) {
      return _(t, [this._element, this._element]);
    }
    _getPopperConfig(t) {
      const e = {
        placement: t,
        modifiers: [
          {
            name: "flip",
            options: { fallbackPlacements: this._config.fallbackPlacements },
          },
          { name: "offset", options: { offset: this._getOffset() } },
          {
            name: "preventOverflow",
            options: { boundary: this._config.boundary },
          },
          {
            name: "arrow",
            options: { element: `.${this.constructor.NAME}-arrow` },
          },
          {
            name: "preSetPlacement",
            enabled: !0,
            phase: "beforeMain",
            fn: (t) => {
              this._getTipElement().setAttribute(
                "data-popper-placement",
                t.state.placement,
              );
            },
          },
        ],
      };
      return { ...e, ..._(this._config.popperConfig, [void 0, e]) };
    }
    _setListeners() {
      const t = this._config.trigger.split(" ");
      for (const e of t)
        if ("click" === e)
          P.on(
            this._element,
            this.constructor.eventName("click"),
            this._config.selector,
            (t) => {
              const e = this._initializeOnDelegatedTarget(t);
              ((e._activeTrigger[hs] = !(e._isShown() && e._activeTrigger[hs])),
                e.toggle());
            },
          );
        else if ("manual" !== e) {
          const t =
              e === ls
                ? this.constructor.eventName("mouseenter")
                : this.constructor.eventName("focusin"),
            i =
              e === ls
                ? this.constructor.eventName("mouseleave")
                : this.constructor.eventName("focusout");
          (P.on(this._element, t, this._config.selector, (t) => {
            const e = this._initializeOnDelegatedTarget(t);
            ((e._activeTrigger["focusin" === t.type ? cs : ls] = !0),
              e._enter());
          }),
            P.on(this._element, i, this._config.selector, (t) => {
              const e = this._initializeOnDelegatedTarget(t);
              ((e._activeTrigger["focusout" === t.type ? cs : ls] =
                e._element.contains(t.relatedTarget)),
                e._leave());
            }));
        }
      ((this._hideModalHandler = () => {
        this._element && this.hide();
      }),
        P.on(this._element.closest(rs), as, this._hideModalHandler));
    }
    _fixTitle() {
      const t = this._element.getAttribute("title");
      t &&
        (this._element.getAttribute("aria-label") ||
          this._element.textContent.trim() ||
          this._element.setAttribute("aria-label", t),
        this._element.setAttribute("data-bs-original-title", t),
        this._element.removeAttribute("title"));
    }
    _enter() {
      this._isShown() || this._isHovered
        ? (this._isHovered = !0)
        : ((this._isHovered = !0),
          this._setTimeout(() => {
            this._isHovered && this.show();
          }, this._config.delay.show));
    }
    _leave() {
      this._isWithActiveTrigger() ||
        ((this._isHovered = !1),
        this._setTimeout(() => {
          this._isHovered || this.hide();
        }, this._config.delay.hide));
    }
    _setTimeout(t, e) {
      (clearTimeout(this._timeout), (this._timeout = setTimeout(t, e)));
    }
    _isWithActiveTrigger() {
      return Object.values(this._activeTrigger).includes(!0);
    }
    _getConfig(t) {
      const e = H.getDataAttributes(this._element);
      for (const t of Object.keys(e)) is.has(t) && delete e[t];
      return (
        (t = { ...e, ...("object" == typeof t && t ? t : {}) }),
        (t = this._mergeConfigObj(t)),
        (t = this._configAfterMerge(t)),
        this._typeCheckConfig(t),
        t
      );
    }
    _configAfterMerge(t) {
      return (
        (t.container = !1 === t.container ? document.body : a(t.container)),
        "number" == typeof t.delay &&
          (t.delay = { show: t.delay, hide: t.delay }),
        "number" == typeof t.title && (t.title = t.title.toString()),
        "number" == typeof t.content && (t.content = t.content.toString()),
        t
      );
    }
    _getDelegateConfig() {
      const t = {};
      for (const [e, i] of Object.entries(this._config))
        this.constructor.Default[e] !== i && (t[e] = i);
      return ((t.selector = !1), (t.trigger = "manual"), t);
    }
    _disposePopper() {
      (this._popper && (this._popper.destroy(), (this._popper = null)),
        this.tip && (this.tip.remove(), (this.tip = null)));
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = ps.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
          e[t]();
        }
      });
    }
  }
  g(ps);
  const ms = ".popover-header",
    gs = ".popover-body",
    _s = {
      ...ps.Default,
      content: "",
      offset: [0, 8],
      placement: "right",
      template:
        '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>',
      trigger: "click",
    },
    bs = { ...ps.DefaultType, content: "(null|string|element|function)" };
  class vs extends ps {
    static get Default() {
      return _s;
    }
    static get DefaultType() {
      return bs;
    }
    static get NAME() {
      return "popover";
    }
    _isWithContent() {
      return this._getTitle() || this._getContent();
    }
    _getContentForTemplate() {
      return { [ms]: this._getTitle(), [gs]: this._getContent() };
    }
    _getContent() {
      return this._resolvePossibleFunction(this._config.content);
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = vs.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
          e[t]();
        }
      });
    }
  }
  g(vs);
  const ys = ".bs.scrollspy",
    ws = `activate${ys}`,
    As = `click${ys}`,
    Es = `load${ys}.data-api`,
    Ts = "active",
    Cs = "[href]",
    Os = ".nav-link",
    xs = `${Os}, .nav-item > ${Os}, .list-group-item`,
    ks = {
      offset: null,
      rootMargin: "0px 0px -25%",
      smoothScroll: !1,
      target: null,
      threshold: [0.1, 0.5, 1],
    },
    Ls = {
      offset: "(number|null)",
      rootMargin: "string",
      smoothScroll: "boolean",
      target: "element",
      threshold: "array",
    };
  class Ss extends B {
    constructor(t, e) {
      (super(t, e),
        (this._targetLinks = new Map()),
        (this._observableSections = new Map()),
        (this._rootElement =
          "visible" === getComputedStyle(this._element).overflowY
            ? null
            : this._element),
        (this._activeTarget = null),
        (this._observer = null),
        (this._previousScrollData = { visibleEntryTop: 0, parentScrollTop: 0 }),
        this.refresh());
    }
    static get Default() {
      return ks;
    }
    static get DefaultType() {
      return Ls;
    }
    static get NAME() {
      return "scrollspy";
    }
    refresh() {
      (this._initializeTargetsAndObservables(),
        this._maybeEnableSmoothScroll(),
        this._observer
          ? this._observer.disconnect()
          : (this._observer = this._getNewObserver()));
      for (const t of this._observableSections.values())
        this._observer.observe(t);
    }
    dispose() {
      (this._observer.disconnect(), super.dispose());
    }
    _configAfterMerge(t) {
      return (
        (t.target = a(t.target) || document.body),
        (t.rootMargin = t.offset ? `${t.offset}px 0px -30%` : t.rootMargin),
        "string" == typeof t.threshold &&
          (t.threshold = t.threshold
            .split(",")
            .map((t) => Number.parseFloat(t))),
        t
      );
    }
    _maybeEnableSmoothScroll() {
      this._config.smoothScroll &&
        (P.off(this._config.target, As),
        P.on(this._config.target, As, Cs, (t) => {
          const e = this._observableSections.get(t.target.hash);
          if (e) {
            t.preventDefault();
            const i = this._rootElement || window,
              n = e.offsetTop - this._element.offsetTop;
            if (i.scrollTo)
              return void i.scrollTo({ top: n, behavior: "smooth" });
            i.scrollTop = n;
          }
        }));
    }
    _getNewObserver() {
      const t = {
        root: this._rootElement,
        threshold: this._config.threshold,
        rootMargin: this._config.rootMargin,
      };
      return new IntersectionObserver((t) => this._observerCallback(t), t);
    }
    _observerCallback(t) {
      const e = (t) => this._targetLinks.get(`#${t.target.id}`),
        i = (t) => {
          ((this._previousScrollData.visibleEntryTop = t.target.offsetTop),
            this._process(e(t)));
        },
        n = (this._rootElement || document.documentElement).scrollTop,
        s = n >= this._previousScrollData.parentScrollTop;
      this._previousScrollData.parentScrollTop = n;
      for (const o of t) {
        if (!o.isIntersecting) {
          ((this._activeTarget = null), this._clearActiveClass(e(o)));
          continue;
        }
        const t =
          o.target.offsetTop >= this._previousScrollData.visibleEntryTop;
        if (s && t) {
          if ((i(o), !n)) return;
        } else s || t || i(o);
      }
    }
    _initializeTargetsAndObservables() {
      ((this._targetLinks = new Map()), (this._observableSections = new Map()));
      const t = R.find(Cs, this._config.target);
      for (const e of t) {
        if (!e.hash || c(e)) continue;
        const t = R.findOne(decodeURI(e.hash), this._element);
        l(t) &&
          (this._targetLinks.set(decodeURI(e.hash), e),
          this._observableSections.set(e.hash, t));
      }
    }
    _process(t) {
      this._activeTarget !== t &&
        (this._clearActiveClass(this._config.target),
        (this._activeTarget = t),
        t.classList.add(Ts),
        this._activateParents(t),
        P.trigger(this._element, ws, { relatedTarget: t }));
    }
    _activateParents(t) {
      if (t.classList.contains("dropdown-item"))
        R.findOne(".dropdown-toggle", t.closest(".dropdown")).classList.add(Ts);
      else
        for (const e of R.parents(t, ".nav, .list-group"))
          for (const t of R.prev(e, xs)) t.classList.add(Ts);
    }
    _clearActiveClass(t) {
      t.classList.remove(Ts);
      const e = R.find(`${Cs}.${Ts}`, t);
      for (const t of e) t.classList.remove(Ts);
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = Ss.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === e[t] || t.startsWith("_") || "constructor" === t)
            throw new TypeError(`No method named "${t}"`);
          e[t]();
        }
      });
    }
  }
  (P.on(window, Es, () => {
    for (const t of R.find('[data-bs-spy="scroll"]')) Ss.getOrCreateInstance(t);
  }),
    g(Ss));
  const Ds = ".bs.tab",
    $s = `hide${Ds}`,
    Is = `hidden${Ds}`,
    Ns = `show${Ds}`,
    Ps = `shown${Ds}`,
    js = `click${Ds}`,
    Ms = `keydown${Ds}`,
    Fs = `load${Ds}`,
    Hs = "ArrowLeft",
    Ws = "ArrowRight",
    Bs = "ArrowUp",
    zs = "ArrowDown",
    Rs = "Home",
    qs = "End",
    Vs = "active",
    Ks = "fade",
    Qs = "show",
    Xs = ".dropdown-toggle",
    Ys = `:not(${Xs})`,
    Us =
      '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]',
    Gs = `.nav-link${Ys}, .list-group-item${Ys}, [role="tab"]${Ys}, ${Us}`,
    Js = `.${Vs}[data-bs-toggle="tab"], .${Vs}[data-bs-toggle="pill"], .${Vs}[data-bs-toggle="list"]`;
  class Zs extends B {
    constructor(t) {
      (super(t),
        (this._parent = this._element.closest(
          '.list-group, .nav, [role="tablist"]',
        )),
        this._parent &&
          (this._setInitialAttributes(this._parent, this._getChildren()),
          P.on(this._element, Ms, (t) => this._keydown(t))));
    }
    static get NAME() {
      return "tab";
    }
    show() {
      const t = this._element;
      if (this._elemIsActive(t)) return;
      const e = this._getActiveElem(),
        i = e ? P.trigger(e, $s, { relatedTarget: t }) : null;
      P.trigger(t, Ns, { relatedTarget: e }).defaultPrevented ||
        (i && i.defaultPrevented) ||
        (this._deactivate(e, t), this._activate(t, e));
    }
    _activate(t, e) {
      t &&
        (t.classList.add(Vs),
        this._activate(R.getElementFromSelector(t)),
        this._queueCallback(
          () => {
            "tab" === t.getAttribute("role")
              ? (t.removeAttribute("tabindex"),
                t.setAttribute("aria-selected", !0),
                this._toggleDropDown(t, !0),
                P.trigger(t, Ps, { relatedTarget: e }))
              : t.classList.add(Qs);
          },
          t,
          t.classList.contains(Ks),
        ));
    }
    _deactivate(t, e) {
      t &&
        (t.classList.remove(Vs),
        t.blur(),
        this._deactivate(R.getElementFromSelector(t)),
        this._queueCallback(
          () => {
            "tab" === t.getAttribute("role")
              ? (t.setAttribute("aria-selected", !1),
                t.setAttribute("tabindex", "-1"),
                this._toggleDropDown(t, !1),
                P.trigger(t, Is, { relatedTarget: e }))
              : t.classList.remove(Qs);
          },
          t,
          t.classList.contains(Ks),
        ));
    }
    _keydown(t) {
      if (![Hs, Ws, Bs, zs, Rs, qs].includes(t.key)) return;
      (t.stopPropagation(), t.preventDefault());
      const e = this._getChildren().filter((t) => !c(t));
      let i;
      if ([Rs, qs].includes(t.key)) i = e[t.key === Rs ? 0 : e.length - 1];
      else {
        const n = [Ws, zs].includes(t.key);
        i = v(e, t.target, n, !0);
      }
      i && (i.focus({ preventScroll: !0 }), Zs.getOrCreateInstance(i).show());
    }
    _getChildren() {
      return R.find(Gs, this._parent);
    }
    _getActiveElem() {
      return this._getChildren().find((t) => this._elemIsActive(t)) || null;
    }
    _setInitialAttributes(t, e) {
      this._setAttributeIfNotExists(t, "role", "tablist");
      for (const t of e) this._setInitialAttributesOnChild(t);
    }
    _setInitialAttributesOnChild(t) {
      t = this._getInnerElement(t);
      const e = this._elemIsActive(t),
        i = this._getOuterElement(t);
      (t.setAttribute("aria-selected", e),
        i !== t && this._setAttributeIfNotExists(i, "role", "presentation"),
        e || t.setAttribute("tabindex", "-1"),
        this._setAttributeIfNotExists(t, "role", "tab"),
        this._setInitialAttributesOnTargetPanel(t));
    }
    _setInitialAttributesOnTargetPanel(t) {
      const e = R.getElementFromSelector(t);
      e &&
        (this._setAttributeIfNotExists(e, "role", "tabpanel"),
        t.id && this._setAttributeIfNotExists(e, "aria-labelledby", `${t.id}`));
    }
    _toggleDropDown(t, e) {
      const i = this._getOuterElement(t);
      if (!i.classList.contains("dropdown")) return;
      const n = (t, n) => {
        const s = R.findOne(t, i);
        s && s.classList.toggle(n, e);
      };
      (n(Xs, Vs), n(".dropdown-menu", Qs), i.setAttribute("aria-expanded", e));
    }
    _setAttributeIfNotExists(t, e, i) {
      t.hasAttribute(e) || t.setAttribute(e, i);
    }
    _elemIsActive(t) {
      return t.classList.contains(Vs);
    }
    _getInnerElement(t) {
      return t.matches(Gs) ? t : R.findOne(Gs, t);
    }
    _getOuterElement(t) {
      return t.closest(".nav-item, .list-group-item") || t;
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = Zs.getOrCreateInstance(this);
        if ("string" == typeof t) {
          if (void 0 === e[t] || t.startsWith("_") || "constructor" === t)
            throw new TypeError(`No method named "${t}"`);
          e[t]();
        }
      });
    }
  }
  (P.on(document, js, Us, function (t) {
    (["A", "AREA"].includes(this.tagName) && t.preventDefault(),
      c(this) || Zs.getOrCreateInstance(this).show());
  }),
    P.on(window, Fs, () => {
      for (const t of R.find(Js)) Zs.getOrCreateInstance(t);
    }),
    g(Zs));
  const to = ".bs.toast",
    eo = `mouseover${to}`,
    io = `mouseout${to}`,
    no = `focusin${to}`,
    so = `focusout${to}`,
    oo = `hide${to}`,
    ro = `hidden${to}`,
    ao = `show${to}`,
    lo = `shown${to}`,
    co = "hide",
    ho = "show",
    uo = "showing",
    fo = { animation: "boolean", autohide: "boolean", delay: "number" },
    po = { animation: !0, autohide: !0, delay: 5e3 };
  class mo extends B {
    constructor(t, e) {
      (super(t, e),
        (this._timeout = null),
        (this._hasMouseInteraction = !1),
        (this._hasKeyboardInteraction = !1),
        this._setListeners());
    }
    static get Default() {
      return po;
    }
    static get DefaultType() {
      return fo;
    }
    static get NAME() {
      return "toast";
    }
    show() {
      P.trigger(this._element, ao).defaultPrevented ||
        (this._clearTimeout(),
        this._config.animation && this._element.classList.add("fade"),
        this._element.classList.remove(co),
        u(this._element),
        this._element.classList.add(ho, uo),
        this._queueCallback(
          () => {
            (this._element.classList.remove(uo),
              P.trigger(this._element, lo),
              this._maybeScheduleHide());
          },
          this._element,
          this._config.animation,
        ));
    }
    hide() {
      this.isShown() &&
        (P.trigger(this._element, oo).defaultPrevented ||
          (this._element.classList.add(uo),
          this._queueCallback(
            () => {
              (this._element.classList.add(co),
                this._element.classList.remove(uo, ho),
                P.trigger(this._element, ro));
            },
            this._element,
            this._config.animation,
          )));
    }
    dispose() {
      (this._clearTimeout(),
        this.isShown() && this._element.classList.remove(ho),
        super.dispose());
    }
    isShown() {
      return this._element.classList.contains(ho);
    }
    _maybeScheduleHide() {
      this._config.autohide &&
        (this._hasMouseInteraction ||
          this._hasKeyboardInteraction ||
          (this._timeout = setTimeout(() => {
            this.hide();
          }, this._config.delay)));
    }
    _onInteraction(t, e) {
      switch (t.type) {
        case "mouseover":
        case "mouseout":
          this._hasMouseInteraction = e;
          break;
        case "focusin":
        case "focusout":
          this._hasKeyboardInteraction = e;
      }
      if (e) return void this._clearTimeout();
      const i = t.relatedTarget;
      this._element === i ||
        this._element.contains(i) ||
        this._maybeScheduleHide();
    }
    _setListeners() {
      (P.on(this._element, eo, (t) => this._onInteraction(t, !0)),
        P.on(this._element, io, (t) => this._onInteraction(t, !1)),
        P.on(this._element, no, (t) => this._onInteraction(t, !0)),
        P.on(this._element, so, (t) => this._onInteraction(t, !1)));
    }
    _clearTimeout() {
      (clearTimeout(this._timeout), (this._timeout = null));
    }
    static jQueryInterface(t) {
      return this.each(function () {
        const e = mo.getOrCreateInstance(this, t);
        if ("string" == typeof t) {
          if (void 0 === e[t]) throw new TypeError(`No method named "${t}"`);
          e[t](this);
        }
      });
    }
  }
  return (
    q(mo),
    g(mo),
    {
      Alert: X,
      Button: U,
      Carousel: St,
      Collapse: qt,
      Dropdown: Qi,
      Modal: Ln,
      Offcanvas: Qn,
      Popover: vs,
      ScrollSpy: Ss,
      Tab: Zs,
      Toast: mo,
      Tooltip: ps,
    }
  );
});
//# sourceMappingURL=bootstrap.bundle.min.js.map
